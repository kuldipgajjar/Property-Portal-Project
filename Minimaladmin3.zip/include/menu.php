<div class="content-wrapper">
 <section class="content-header">
      <h1>
       <?php 
			   if(isset($_SESSION['log']))
			   {
				   echo "Welcome &nbsp".$_SESSION['log'];
			   }
			   else
			   {
				   header("location:index.php");
			   }
         ?>
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
	</section>
	    
	</div>
	