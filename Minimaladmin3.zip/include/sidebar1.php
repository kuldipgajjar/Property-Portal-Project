  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
	<?php
	 
			 $id=$_SESSION['id'];
						 
			$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
			$query="select * from agent where agent_id='$id'";
			$result=mysqli_query($con,$query);						
			$row=mysqli_fetch_array($result);
	?>
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image float-left">
          <img src="<?php echo $row['agent_photo']; ?>" class="rounded-circle" alt="User Image">
        </div>
        <div class="info float-left">
          <p>
		  <?php  						
			  echo "Welcome &nbsp".$row['agentname'];
			?>
	  </p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
		  <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      </div>
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        
        <li class="active">
          <a href="index12.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
	     <li class="treeview">
          <a href="#">
            <i class="fa fa-commenting-o"></i> <span>view inquiry</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
		  <ul class="treeview-menu">
            <li><a href="agentviewinquiry.php">View</a></li>
          </ul>
        </li>
    </section>
	
    <!-- /.sidebar -->
      </aside>
<script>
	/*	function useradd(str) 
		 {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() 
			{
					if (this.readyState == 4 && this.status == 200)
					{						
						document.getElementById("adduser").innerHTML =this.responseText;						
				    }
			};
			if(str==1)
			{
			xhttp.open("GET", "adduser.php", true);
			xhttp.send(); 
			}
			else if(str==2)
			{
			xhttp.open("GET", "viewuser.php", true);
			xhttp.send(); 
			}
			else if(str==3)
			{
			xhttp.open("GET", "addcity.php", true);
			xhttp.send(); 	
			}
			else if(str==4)
			{
			xhttp.open("GET", "viewcity.php", true);
			xhttp.send(); 	
			}
		}
		
		<!----------------------Insert User Data -------------------->
							
		function user_insert() 
			{
				var xhttp = new XMLHttpRequest();
								
				var insert = document.getElementById("insert").value;
				var firstname = document.getElementById("firstname").value;
				var lastname = document.getElementById('lastname').value;
				var email = document.getElementById('email').value;
				var password = document.getElementById('password').value;
				var address = document.getElementById('address').value;
				var phone = document.getElementById("phone").value;
				if(document.getElementById('gender1').checked)
				{
					var gender = document.getElementById('gender1').value;
				}
				else
				{
					var gender = document.getElementById('gender2').value;
				}
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("this").innerHTML = this.responseText;
							}
						};
						
				  xhttp.open("GET", "adduser.php?firstname="+firstname+"&lastname="+lastname+"&email="+email+"&password="+password+"&address="+address+"&phone="+phone+"&gender="+gender+"&insert=insert",true);
				  xhttp.send();
				 
			}
			function user_update() 
			{
				var xhttp = new XMLHttpRequest();
				
				var upid = document.getElementById("upid").value;
				var firstname = document.getElementById("firstname1").value;
				var lastname = document.getElementById('lastname1').value;
				var email = document.getElementById('email1').value;
				var password = document.getElementById('password1').value;
				var address = document.getElementById('address1').value;
				var phone = document.getElementById("phone1").value;
				if(document.getElementById('gender3').checked)
				{
					var gender = document.getElementById('gender3').value;
				}
				else if(document.getElementById('gender4').checked)
				{
					var gender = document.getElementById('gender4').value;
				}
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("this").innerHTML = this.responseText;
							}
						};						
				  xhttp.open("GET", "adduser.php?firstname="+firstname+"&lastname="+lastname+"&email="+email+"&password="+password+"&address="+address+"&phone="+phone+"&gender="+gender+"&upid="+upid+"",true);
				  xhttp.send();
				 
			}
			function user_update1(str) 
			{
				var xhttp = new XMLHttpRequest();
								
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("this").innerHTML = this.responseText;
							}
						};						
				  xhttp.open("GET", "adduser.php?eid="+str,true);
				  xhttp.send();
			}
			function user_delete(str) 
			{
				var xhttp = new XMLHttpRequest();
								
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("this").innerHTML = this.responseText;
							}
						};						
				  xhttp.open("GET", "adduser.php?did="+str,true);
				  xhttp.send();
			}
			<!---------------------------------------------------->
			<!----------Add city--------------------->
			
			function city_insert() 
			{
				var xhttp = new XMLHttpRequest();
								
				var insert = document.getElementById("insert1").value;
				var city = document.getElementById("city").value;
								
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("city1").innerHTML = this.responseText;
							}
					};
				  xhttp.open("GET", "addcity.php?city="+city+"&insert=insert",true);
				  xhttp.send();
			}
			function city_update() 
			{
				var xhttp = new XMLHttpRequest();
								
				var upid = document.getElementById("upid1").value;
				var city = document.getElementById("city12").value;
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("city1").innerHTML = this.responseText;
							}
					};
				  xhttp.open("GET", "addcity.php?city="+city+"&upid="+upid+" ",true);
				  xhttp.send();
			}
			function city_update1(str) 
			{
				var xhttp = new XMLHttpRequest();
								
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else 
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("city1").innerHTML = this.responseText;
							}
						};						
				  xhttp.open("GET", "addcity.php?eid="+str,true);
				  xhttp.send();
			}
			function city_delete(str) 
			{
				var xhttp = new XMLHttpRequest();
								
					if (window.XMLHttpRequest) 
					{
						xhttp = new XMLHttpRequest();
					} 
					else                                    
					{
						 xhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								document.getElementById("city1").innerHTML = this.responseText;
							}
						};						
				  xhttp.open("GET", "addcity.php?did="+str,true);
				  xhttp.send();
			}
		<!------------------------------------------------------------->
		<!---------------------Add Area------------------------------->
*/
	function pro_category(str)
			{
				var xhttp;
				if(window.XMLHttpRequest)
				{
					xhttp= new XMLHttpRequest();
				}
				else
				{
					xhttp= new ActiveXObject("Microsoft.XMLHTTP");
				}
				
				xhttp.onreadystatechange=function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						document.getElementById("demo1").innerHTML=this.responseText;
					}
				};
				
				
				xhttp.open("GET","ajaxdropdown.php?data1="+str,true);
				xhttp.send();
			}
	
	function pro_city(str)
			{
				var xhttp;
				if(window.XMLHttpRequest)
				{
					xhttp= new XMLHttpRequest();
				}
				else
				{
					xhttp= new ActiveXObject("Microsoft.XMLHTTP");
				}
				
				xhttp.onreadystatechange=function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						document.getElementById("demo2").innerHTML=this.responseText;
					}
				};
				
				
				xhttp.open("GET","ajaxdropdown.php?data2="+str,true);
				xhttp.send();
			}
	
</script>