<?php 
	   if(isset($_SESSION['id']))
	   {
	   }
	   else
	   {
	     header("location:agentlogin.php");
	   }
	   
?> 
  <a href="index12.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="images/minimal.png"  alt=""></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Admin</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
			<?php
				 if(isset($_SESSION['id']))
					{
						 $id=$_SESSION['id'];
						 
						$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
						$query="select * from agent where agent_id='$id'";
						$result=mysqli_query($con,$query);						
						$row=mysqli_fetch_array($result);					
						?>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
		  <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo $row['agent_photo']; ?>" class="user-image rounded-circle" alt="User Image">
            </a>
            <ul class="dropdown-menu scale-up">
              <!-- User image -->
              <li class="user-header">
			  
                <img src="<?php echo $row['agent_photo']; ?>" class="float-left rounded-circle" alt="User Image">

                <p>                
						<li></li>
					
				   <small class="mb-5" style="margin-left:31px;font-size:17px;"><?php echo $row['agentname'];?></small>
                  
				  
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row no-gutters">
                  <div class="col-12 text-left">
                    <a href="editagent.php?eid=<?php echo $row['agent_id']; ?>"><i class="ion ion-person"></i> My Profile</a>
                  </div>
                                  
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
               
				
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-block btn-danger"><i class="ion ion-power"></i> Log Out</a>
                </div>
              </li>
            </ul>
          </li>
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-cog fa-spin"></i></a>
          </li>
        </ul>
	</div>
		<?php
		}
		?>