﻿<!DOCTYPE html>
<?php
session_start();
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
if(isset($_POST['submit']))
{
		$firstname=$_POST['name'];
		$email=$_POST['email'];	
		$phone=$_POST['mobile'];
		$password=$_POST['password'];
		
		$src_path=$_FILES['photo']['tmp_name'];
		$name=$_FILES['photo']['name'];
		$name=rand(1,100000).$name;
		$dest_path="images/agent/".$name;
		
		move_uploaded_file($src_path,$dest_path);
		
		$query="insert into agent values('','$firstname','$email','$phone','$password','$dest_path')";
		mysqli_query($con,$query);
		header("location:viewagent.php");
}

if(isset($_GET['eid']))
{
	$id=$_GET['eid'];
		
	
	$query="select * from agent where agent_id=$id";
	$result=mysqli_query($con,$query);
	$row=mysqli_fetch_array($result);
}
if(isset($_GET['did']))
{
	$id=$_GET['did'];
		
	$result=mysqli_query($con,"select * from agent where agent_id='$id'");
	$row1=mysqli_fetch_array($result);
	$img_delete=$row1['agent_photo'];
	
	unlink($img_delete);
	$query="delete from agent where agent_id='$id'";
	mysqli_query($con,$query);
	header("location:viewagent.php");
}
if(isset($_POST['edit']))
{
		$id=$_GET['eid'];
		$firstname=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['mobile'];
		$password=$_POST['password'];

		$src_path=$_FILES['photo']['tmp_name'];
		$name=$_FILES['photo']['name'];
		$name=rand(1,100000).$name;
		$dest_path="images/agent/".$name;
		
		move_uploaded_file($src_path,$dest_path);
		
		if($_FILES['photo']['name']=="")
		{
			$query="update agent set agentname='$firstname',agentemail='$email',agentphone='$phone',agent_password='$password' where agent_id='$id'";
		}
		else
		{
			$query="update agent set agentname='$firstname',agentemail='$email',agentphone='$phone',agent_password='$password',agent_photo='$dest_path' where agent_id='$id'";
		}	
	mysqli_query($con,$query);
	header("location:viewagent.php");
}

?>
<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from html-templates.multipurposethemes.com/bootstrap-4/admin/minimaladmin/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Nov 2017 00:46:38 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.ico">

    <title> Admin - Dashboard</title>
    
	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap.css">
	
	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap-extend.css">
	
	<!-- font awesome -->
	<link rel="stylesheet" href="assets/vendor_components/font-awesome/css/font-awesome.css">
	
	<!-- ionicons -->
	<link rel="stylesheet" href="assets/vendor_components/Ionicons/css/ionicons.css">
	
	<!-- theme style -->
	<link rel="stylesheet" href="css/master_style.css">
	
	<!-- minimal_admin skins. choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
	<link rel="stylesheet" href="css/skins/_all-skins.css">
	
	<!-- weather weather -->
	<link rel="stylesheet" href="assets/vendor_components/weather-icons/weather-icons.css">
	
	<!-- jvectormap -->
	<link rel="stylesheet" href="assets/vendor_components/jvectormap/jquery-jvectormap.css">
	
	<!-- date picker -->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.css">
	
	<!-- daterange picker -->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap-daterangepicker/daterangepicker.css">
	
	<!-- bootstrap wysihtml5 - text editor -->
	<link rel="stylesheet" href="assets/vendor_plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.css">
	

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

     
  </head>

<body class="hold-transition skin-blue sidebar-mini">


  <header class="main-header">
    <!-- Logo -->
  <?php
  include("include/header.php");
  ?>


  </header>
  
  <!-- Left side column. contains the logo and sidebar -->
<?php
include("include/sidebar.php");
?>
  <!-- Content Wrapper. Contains page content -->
<div id="this">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <section class="content-header">
      <h1>
        Add AGENT
        
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
		<li class="breadcrumb-item active">Addagent</li>
      </ol>
	</section>
	
	<div class="box box-warning">
	     <div class="box-body">
		 
				<form action="" method="post" enctype="multipart/form-data" name="myForm" onsubmit="return(validate());">
				<div class="box box-default">
				<div class="box-header with-border">
			  	<!-- text input -->				
                <div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['eid'])){ echo $row['agentname'];}?>" name="name" id="firstname1" placeholder="Enter name">
                <span style="color:red;" id="name"></span>
				</div>				
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['eid'])){ echo $row['agentemail'];}?>" name="email" id="email1" placeholder="Enter Email">
                <span style="color:red;" id="email"></span>
				</div>							
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['eid'])){ echo $row['agentphone'];}?>" name="mobile" id="phone1" placeholder="Enter Phoneno">
                <span style="color:red;" id="mobile"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['eid'])){ echo $row['agent_password'];}?>" name="password" id="phone1" placeholder="Enter password">
                <span style="color:red;" id="password"></span>
				</div>				
				<div class="form-group">
				 <?php if(isset($_GET['eid'])){?><img src=" <?php echo $row['agent_photo'];?>"width="100px"style="float:right;"><?php } ?><input type="file" name="photo"id="photo">
                
				</div>
				<button type="submit"  name="<?php if(isset($_GET['eid'])){echo"edit";}else{echo"submit";}?>"  style="width:200px;" class="btn btn-primary"><?php if(isset($_GET['eid'])){echo"EDIT";}else{echo"ADD";}?></button>
			</form>              
	     </div>
     </div>
 </div>
</div>
 
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li class="nav-item"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li class="nav-item"><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-cog fa-spin"></i></a></li>
    </ul>
 </aside>
</div>
<script type="text/javascript">
function validate()
      {
		  var name = document.myForm.name.value;
		  var email = document.myForm.email.value;
		  var mobile = document.myForm.mobile.value;
		  var pass = document.myForm.password.value;	  
		   
		 
		   //alert(fup);
		if(name == "")
		 {
		 document.getElementById("name").innerHTML="Please Fill Name Filed.";
		 document.myForm.name.focus() ;
            return false;
         }
		 else{
			 document.getElementById("name").innerHTML="";
		 }
		 if( email == "" )
         {
            document.getElementById("email").innerHTML="Please Fill the username field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.length <= 5) || (email.length > 25) )
		 {
			document.getElementById("email").innerHTML="user length must be between 5 and 25";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email").innerHTML="";
		 } 		
		 if( mobile == "")
		 {
			document.getElementById("mobile").innerHTML="Please Fill the Mobile field";
            document.myForm.mobile.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(isNaN(mobile))
		 {
			document.getElementById("mobile").innerHTML="User Must Enter Digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(mobile.length !=10)
		 {
			document.getElementById("mobile").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }		 
		
		 if( pass == "" )
         {
            document.getElementById("password").innerHTML="Please Fill the password field";
            document.myForm.password.focus() ;
            return false;
         }
		 else{
			document.getElementById("password").innerHTML=""; 
		 }
		 if((pass.length <= 5) || (pass.length > 20) )
		 {
			document.getElementById("password").innerHTML="password length must be between 5 and 20";
            document.myForm.password.focus() ;
            return false;
		 }	
		else{
			document.getElementById("password").innerHTML=""; 
		 }
		
		
		 return( true );
	  }
</script>
	<!-- jQuery 3 -->
	<script src="assets/vendor_components/jquery/dist/jquery.js"></script>
	
	<!-- jQuery UI 1.11.4 -->
	<script src="assets/vendor_components/jquery-ui/jquery-ui.js"></script>
	
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	  $.widget.bridge('uibutton', $.ui.button);
	</script>
	
	<!-- popper -->
	<script src="assets/vendor_components/popper/dist/popper.min.js"></script>
	
	<!-- Bootstrap 4.0-->
	<script src="assets/vendor_components/bootstrap/dist/js/bootstrap.js"></script>	
	
	<!-- ChartJS -->
	<script src="assets/vendor_components/chart-js/chart.js"></script>
	
	<!-- Sparkline -->
	<script src="assets/vendor_components/jquery-sparkline/dist/jquery.sparkline.js"></script>
	
	<!-- jvectormap -->
	<script src="assets/vendor_plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>	
	<script src="assets/vendor_plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	
	<!-- jQuery Knob Chart -->
	<script src="assets/vendor_components/jquery-knob/js/jquery.knob.js"></script>
	
	<!-- daterangepicker -->
	<script src="assets/vendor_components/moment/min/moment.min.js"></script>
	<script src="assets/vendor_components/bootstrap-daterangepicker/daterangepicker.js"></script>
	
	<!-- datepicker -->
	<script src="assets/vendor_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.js"></script>
	
	<!-- Bootstrap WYSIHTML5 -->
	<script src="assets/vendor_plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.js"></script>
	
	<!-- Slimscroll -->
	<script src="assets/vendor_components/jquery-slimscroll/jquery.slimscroll.js"></script>
	
	<!-- FastClick -->
	<script src="assets/vendor_components/fastclick/lib/fastclick.js"></script>
	
	<!-- minimal_admin App -->
	<script src="js/template.js"></script>
	
	<!-- minimal_admin dashboard demo (This is only for demo purposes) -->
	<script src="js/pages/dashboard.js"></script>
	
	<!-- minimal_admin for demo purposes -->
	<script src="js/demo.js"></script>
	
	<!-- weather for demo purposes -->
	<script src="assets/vendor_plugins/weather-icons/WeatherIcon.js"></script>

	
</body>

<!-- Mirrored from html-templates.multipurposethemes.com/bootstrap-4/admin/minimaladmin/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Nov 2017 00:47:35 GMT -->
</html>
