<?php
include("include/header.php");
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
$page_name=basename($_SERVER['REQUEST_URI']);
$full_url = "http://localhost/homy/".$page_name;

			$limit = 6;  
			if (isset($_GET["page"]))
			{
				$page  = $_GET["page"];
			}
			else 
			{ 
				$page=1; 
			};  
				$start_from = ($page-1) * $limit;
				
			 if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && isset($_GET['floor1']) && isset($_GET['furnished1']) && isset($_GET['minarea1']) && isset($_GET['maxarea1']) && isset($_GET['check1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="" && $_GET['floor1'] !="" && $_GET['furnished1'] !="" && $_GET['minarea1'] !="" && $_GET['maxarea1'] !="" && $_GET['check1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					$floor1=$_GET['floor1'];
					$furnished1=$_GET['furnished1'];
					$minarea1=$_GET['minarea1'];
					$maxarea1=$_GET['maxarea1'];
					$check1=$_GET['check1'];
						
						$check_first = $check1[0];
						$string="AND features LIKE '%$check_first%'";
						for($i=1; $i<count($check1); $i++)
						{
							$check_other = $check1[$i];
							$string.=" AND features LIKE '%$check_other%'";							
						}						
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1 AND maxarea <= $maxarea1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1'".$string." ".$order." LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1 AND maxarea <= $maxarea1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1'".$string." ".$order;
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && isset($_GET['floor1']) && isset($_GET['furnished1']) && isset($_GET['minarea1']) && isset($_GET['maxarea1'])  && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="" && $_GET['floor1'] !="" && $_GET['furnished1'] !="" && $_GET['minarea1'] !="" && $_GET['maxarea1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					$floor1=$_GET['floor1'];
					$furnished1=$_GET['furnished1'];
					$minarea1=$_GET['minarea1'];
					$maxarea1=$_GET['maxarea1'];
					
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1 AND maxarea >= $maxarea1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1 AND maxarea >= $maxarea1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && isset($_GET['floor1']) && isset($_GET['furnished1']) && isset($_GET['minarea1'])  && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="" && $_GET['floor1'] !="" && $_GET['furnished1'] !="" && $_GET['minarea1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					$floor1=$_GET['floor1'];
					$furnished1=$_GET['furnished1'];
					$minarea1=$_GET['minarea1'];					
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND minarea >= $minarea1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && isset($_GET['floor1']) && isset($_GET['furnished1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="" && $_GET['floor1'] !="" && $_GET['furnished1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					$floor1=$_GET['floor1'];
					$furnished1=$_GET['furnished1'];									
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND  propertydetail.furnished_id='$furnished1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && isset($_GET['floor1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="" && $_GET['floor1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					$floor1=$_GET['floor1'];														
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1 AND floor <= $floor1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && isset($_GET['maxprice1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="" && $_GET['maxprice1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];									
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1 AND maxprice <= $maxprice1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && isset($_GET['minprice1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="" && $_GET['minprice1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					$minprice1=$_GET['minprice1'];									
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND maxprice >= $minprice1  AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && isset($_GET['area1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="" && $_GET['area1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];
					$area1=$_GET['area1'];
					
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND area_id='$area1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1']) && isset($_GET['city1']) && $_GET['type1'] !="" && $_GET['bhk1'] !="" && $_GET['city1'] !="")
				{
						$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];
					$city1=$_GET['city1'];										
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND cityid='$city1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) && isset($_GET['bhk1'])  && $_GET['type1'] !="" && $_GET['bhk1'] !="")
				{	
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					
					$type1=$_GET['type1'];
					$bhk1=$_GET['bhk1'];												
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.category_id='$type1' AND propertydetail.subcat_id='$bhk1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['type1']) &&  $_GET['type1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$type1=$_GET['type1'];													
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where  propertydetail.category_id='$type1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['bhk1']) &&  $_GET['bhk1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$bhk1=$_GET['bhk1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.subcat_id='$bhk1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.subcat_id='$bhk1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['city1']) &&  $_GET['city1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$city1=$_GET['city1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where cityid='$city1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where cityid='$city1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['area1']) &&  $_GET['area1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$area1=$_GET['area1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where area_id='$area1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where area_id='$area1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['minprice1']) &&  $_GET['minprice1'] !="" && isset($_GET['maxprice1']) &&  $_GET['maxprice1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$minprice1=$_GET['minprice1'];
					$maxprice1=$_GET['maxprice1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where maxprice >= $minprice1 AND maxprice <= $maxprice1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where maxprice >= $minprice1 AND maxprice <= $maxprice1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['floor1']) &&  $_GET['floor1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$floor1=$_GET['floor1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where floor <= $floor1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where floor <= $floor1 AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if(isset($_GET['furnished1']) &&  $_GET['furnished1'] !="")
				{		
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}					
					$furnished1=$_GET['furnished1'];
					
					$query="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.furnished_id='$furnished1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,p_subcategory,furnished,signup where propertydetail.furnished_id='$furnished1' AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id  AND propertydetail.propertystatus_id='1' $order";
				}
				else if( isset($_GET['check1']) && $_GET['check1']!="")
				{
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					$check1=$_GET['check1'];
						
						$check_first = $check1[0];
						$string="AND features LIKE '%$check_first%'";
						for($i=1; $i<count($check1); $i++)
						{
							$check_other = $check1[$i];
								$string.=" AND features LIKE '%$check_other%'";
							
						}								
					$query="select * from propertydetail,propertystatus,furnished,p_subcategory,signup where propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.propertystatus_id='1' ".$string." ".$order." LIMIT $start_from, $limit";
					$query1="select * from propertydetail,propertystatus,furnished,p_subcategory,signup where propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.propertystatus_id='1'".$string." ".$order;			
				}
				else
				{			
				
					$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					if(isset($_GET['order']))
					{
						
						if($_GET['order']=="asc")
						{
								$order = 'ORDER BY `propertydetail`.`maxprice` ASC';
					
						}
						else
						{
							if($_GET['order']=="desc")
							{
								$order = 'ORDER BY `propertydetail`.`maxprice` DESC';
					
							}
						}
						
					}
					//$query="select * from propertydetail,propertystatus,furnished,p_subcategory,signup where propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.signup_id=signup.signup_id GROUP by propertydetail_id $order LIMIT $start_from, $limit";
				$query="select * from propertydetail,propertystatus,furnished,p_subcategory,signup where propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.propertystatus_id='1' $order LIMIT $start_from, $limit";		
				$query1="select * from propertydetail,propertystatus,furnished,p_subcategory,signup where propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.propertystatus_id='1' $order";
				}
					$result=mysqli_query($con,$query);
					$count=mysqli_num_rows($result);
						
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-list-leftsidebar.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:23 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>
<!-- Top header start -->
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>Properties List</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Properties List</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Properties section body start -->
<div class="properties-section-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12 col-md-push-4">
                <!-- Option bar start -->
                <div class="option-bar">
                    <div class="row">
                        <div class="col-lg-6 col-md-5 col-sm-5 col-xs-2">
                            <h4>
                                <span class="heading-icon">
                                    <i class="fa fa-th-list"></i>
                                </span>
                                <span class="hidden-xs">Properties List</span>
                            </h4>
                        </div>
                        <?php
						if($count==1 || $count==0 )
						{
								?>
							<div class="col-lg-6 col-md-7 col-sm-7 col-xs-10 cod-pad">
                            <div class="sorting-options">
                                                           
                                <a href="#" class="change-view-btn active-view-btn"><i class="fa fa-th-list" style="margin-top:10px;"></i></a>
                            </div>
                        </div>
								<?php
						}
						else
						{
							?>
						<div class="col-lg-6 col-md-7 col-sm-7 col-xs-10 cod-pad">
                            <div class="sorting-options">
                                                           
                                <a href="#" class="change-view-btn active-view-btn"><i class="fa fa-th-list"></i></a>
                            </div>
                        </div>
							<?php
						}
						?>
						
                    </div>
                </div>
				<script>
				 function GetSelectedTextValue(ddlFruits) {
							var selectedText = ddlFruits.options[ddlFruits.selectedIndex].innerHTML;
							var selectedValue = ddlFruits.value;
							var final_url ; 
							var url = "<?php  echo $full_url; ?>";
							pos = url.indexOf('order');
							//alert(pos);
							if(pos==-1)
							{
							 final_url = url+"?order="+selectedValue;
							}
							else
							{
							 final_url = url+"&order="+selectedValue;
							}
							window.location = final_url;
       // alert("Selected Text: " + selectedText + " Value: " + selectedValue);
    }
				</script>
				<?php
					if($count==0)
						{
							echo  "<h1>Record Not Avalilabel</h1> Search Another Record"; 
						}
					while($row=mysqli_fetch_array($result))
					{
				?>
							               
                <div class="listing-properties-box wow fadeInUp delay-03s" >
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 listing-propertie-theme">
							<?php
								$img=explode(',',$row['photo']);
								$number_of_photos = count($img);
								 
								$flag = 0;
								for ($i1=0; $i1<$number_of_photos; $i1++) 
								{
									if($flag==0)
									{
										$flag=1;	
								?>
									<img src="../minimaladmin/<?php echo $img[$i1];?>" alt="properties-1" class="img-responsive">
								<?php
									}
								}
								?>
                        <!-- Tag -->
                        <span class="tag-f-left">
                            <a href="#">RS <?php echo $row['maxprice']; ?></a>
                        </span>
                        <span class="tag-s-right">
                            <a href="#"><?php echo $row['propertystatus']; ?></a>
                        </span>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-15 detail">
                        <!-- Header -->
                        <header class="clearfix">
                            <div class="pull-left">
                                <h1 class="title">
                                    <a href="#"><?php echo $row['propertytitle']; ?></a> ( <?php echo $row['subcategory']; ?> )
                                </h1>
								<h3 class="location">
                                    <a href="#">
                                        <i class="fa fa-map-marker"></i><?php echo $row['floorno']?> <?php echo $row['complexname']?>
                                    </a>
                                </h3>
								
                            </div>
													
                            <!-- Btn -->
                            <div class="pull-right">
                                <a href="propertiesdetails.php?detail_id=<?php echo $row['propertydetail_id'];?>" class="button-sm button-theme">Details</a>
                            </div>
                        </header>
                        <!-- Facilities list start -->
                        <ul class="facilities-list clearfix">
                            <li class="bordered-right">
                                <i class="flaticon-square-layouting-with-black-square-in-east-area"></i>
                                <span><?php echo $row['maxarea'];?> sq ft</span>
                            </li>
                            <li>
                                <i class="flaticon-bed"></i>
                                <span><?php echo $row['rooms'];?> Bedroom</span>
                            </li>
                            <li>
                                <i class="flaticon-holidays"></i>
                                <span><?php echo $row['bathrooms'];?> Bathroom </span>
                            </li>
                            
                            <li>
                                <i class="flaticon-building"></i>
                                <span><?php echo $row['balconey'];?> Balcony</span>
                            </li>
							<li>
                                <i class="flaticon-monitor"></i>
                                <span> <?php echo $row['furnished']; ?> Furnished</span>
                            </li>
							<li>
                                <i class="fa fa-home"></i>
                                <span> <?php echo $row['cons_status']; ?></span>
                            </li>
                        </ul>
                        <!-- footer -->
                        <div class="footer">
                            <a href="#">
							<a href="guest.php?eid=<?php echo $row['signup_id']; ?>&&pid=<?php echo $row['propertydetail_id']; ?>"> <button class="search-button" style="padding:8px 8px;background:red;width:130px;">Contact <?php echo $row['user_type']; ?></button></a>
                             </a>
						<a href="#">						
							<a href="feedback.php?pid=<?php echo $row['propertydetail_id']; ?>"> <button class="search-button" style="padding:8px 8px;background:red;width:130px;">Send Feedback</button></a>
						</a>
                            <span>
                                <i class="fa fa-calendar-o"></i> <?php echo $row['date'];  ?>
                            </span>
                        </div>
                    </div>
                </div>
					<?php
					}
					?>
				<!-- Page navigation start -->
                <nav aria-label="Page navigation">
				<ul class="pagination"> 
				<?php 
					if(isset($_GET['page']))
					{
						$rs_result = mysqli_query($con,$query1);  
						 $row = mysqli_num_rows($rs_result);  
						 $total_records = $row;  
						$total_pages = ceil($total_records / $limit);  				
					                                       
						
						  if($page==1)
						  {
						  }
						  else
						  {
						?>
						<li>
                            <a href="<?php echo  $page_name;?>&page=<?php echo $page-1;?>" aria-label="Previous">                                
								<span aria-hidden="true">Previous</span>
                            </a>
                        </li>
						<?php
						  }
						 for ($i=1; $i<=$total_pages; $i++)
						{ 
						?>
                        <li class="active"><a href="<?php echo  $page_name;?>&page=<?php echo $i;?>"><?php echo $i;?></a></li>
                        <?php
						}
						if($total_pages==$page)
						  {
						  }
						  else
						  {
						?>
                        <li>
                            <a href="<?php echo  $page_name;?>&page=<?php echo $page+1;?>" aria-label="Next">
                                <span aria-hidden="true">Next</span>
                            </a>
                        </li>
						<?php
						  }
						}
						  else
						  {
							$rs_result = mysqli_query($con,$query1);  
							$row = mysqli_num_rows($rs_result);  
							$total_records = $row;  
							$total_pages = ceil($total_records / $limit);  				
					
						  if($page==1)
						  {
						  }
						  else
						  {
						?>
						<li>
                            <a href="<?php echo  $page_name;?>?page=<?php echo $page-1;?>" aria-label="Previous">                                
								<span aria-hidden="true">Previous</span>
                            </a>
                        </li>
						<?php
						  }
						 for ($i=1; $i<=$total_pages; $i++)
						{ 
						?>
                        <li class="active"><a href="<?php echo  $page_name;?>?page=<?php echo $i;?>"><?php echo $i;?></a></li>
                        <?php
						}
						if($total_pages==$page)
						  {
						  }
						  else
						  {
						?>
                        <li>
                            <a href="<?php echo  $page_name;?>?page=<?php echo $page+1;?>" aria-label="Next">
                                <span aria-hidden="true">Next</span>
                            </a>
                        </li>
						<?php
						  }
						  }
						?>
						
                    </ul>
                </nav>
                <!-- Page navigation end-->
            </div>
            <div class="col-lg-4 col-md-4 col-xs-12 col-md-pull-8">
                <!-- Search contents sidebar start -->
                <div class="sidebar sidebar-widget">
                    <h3 class="title">Find your House</h3>
                    <form action="rent.php" method="">                       				   					   
                        
                        <div class="form-group">
						<?php
						$query="select * from p_category";
						$result3=mysqli_query($con,$query);
						?>
                            <select class="selectpicker search-fields" name="type1">
                                <option value="" hidden>Search Type</option>
                            <?php
								while($row3=mysqli_fetch_array($result3))
									{
							?>
								<option value="<?php echo $row3['category_id']; ?>"><?php echo $row3['categoryname']; ?></option>
							<?php
									}
							?>        
                            </select>
                        </div>
						<div class="form-group">
						<?php
						$query="select * from p_subcategory";
						$result13=mysqli_query($con,$query);
						?>
                            <select class="selectpicker search-fields" name="bhk1">
                                <option value="" hidden>Search BHK</option>
                            <?php
								while($row13=mysqli_fetch_array($result13))
									{
							?>
								<option value="<?php echo $row13['subcat_id']; ?>"><?php echo $row13['subcategory']; ?></option>
							<?php
									}
							?>        
                            </select>
                        </div>
						<div class="form-group">
						<?php
							$query="select * from city";
							$result=mysqli_query($con,$query);
						?>	
                            <select class="selectpicker search-fields"name="city1" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="" hidden>Search City</option>
                                <?php
										while($row4=mysqli_fetch_array($result))
										{
								?>
									<option value="<?php echo $row4['cityid']; ?>"> <?php echo $row4['cityname']; ?></option>
								<?php
										}
								?>  
                            </select>
                        </div>
						<div class="form-group">
						<?php
							$query="select * from area";
							$result11=mysqli_query($con,$query);
						?>	
                            <select class="selectpicker search-fields" name="area1" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="" hidden>Search area</option>
                                <?php
										while($row11=mysqli_fetch_array($result11))
										{
								?>
									<option value="<?php echo $row11['area_id']; ?>"> <?php echo $row11['areaname']; ?></option>
								<?php
										}
								?>  
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields" name="minprice1">
                                        <option value="" hidden>Min Price</option>
										<option value="5000">5 Thousand</option>
										<option value="500000">5 Lac</option>
										<option value="1000000">10 Lac</option>
										<option value="2000000">20 Lac</option>
										<option value="4000000">40 Lac</option>
										<option value="6000000">60 Lac</option>
										<option value="8000000">80 Lac</option>
										<option value="10000000">1 Cr</option>
										<option value="12000000">1.2 Cr</option>
										<option value="14000000">1.4 Cr</option>
										<option value="16000000">1.6 Cr</option>
										<option value="18000000">1.8 Cr</option>
										<option value="20000000">2.0 Cr</option> 
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields" name="maxprice1"  data-live-search="true">
                                        <option value="" hidden>Max Price</option>
										<option value="100000">1 Lac</option>
										<option value="500000">5 Lac</option>
										<option value="1000000">10 Lac</option>
										<option value="2000000">20 Lac</option>
										<option value="4000000">40 Lac</option>
										<option value="6000000">60 Lac</option>
										<option value="8000000">80 Lac</option>
										<option value="10000000">1 Cr</option>
										<option value="12000000">1.2 Cr</option>
										<option value="14000000">1.4 Cr</option>
										<option value="16000000">1.6 Cr</option>
										<option value="18000000">1.8 Cr</option>
										<option value="20000000">2.0 Cr</option>
                                    </select>
                                </div>
                            </div>
                        </div>
						<div class="row">
						<div class="col-lg-6">
                                <div class="form-group">
                                    <select class="selectpicker search-fields" name="floor1" data-live-search="true">
                                        <option value="" hidden>Floor</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
										
                                    </select>
                                </div>
                            </div>
							<div class="col-lg-6">
							<?php
							$query="select * from furnished";
							$result15=mysqli_query($con,$query);
							?>
                                <div class="form-group">
                                    <select class="selectpicker search-fields" name="furnished1" data-live-search="true">
                                        <option value="" hidden>Furnished</option>
										<?php
										while($row15=mysqli_fetch_array($result15))
										{
										?>
											<option value="<?php echo $row15['furnished_id']; ?>"><?php echo $row15['furnished']; ?></option>
										<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
						</div>
						<div class="row">
                            <div class="col-lg-6">
								<div class="form-group">
									<input class="form-control search-fields" name="minarea1" placeholder="Search Minarea">
								</div>
							</div>						
							<div class="col-lg-6">
								<div class="form-group">
									<input class="form-control search-fields" name="maxarea1" placeholder="Search Maxarea">
								</div>
							</div>
							<input type="hidden" name="page" value="1">
						</div>
                        <a class="show-more-options" data-toggle="collapse" data-target="#options-content">
                            <i class="fa fa-plus-circle"></i> Show More Options
                        </a>
                        <div id="options-content" class="collapse">
                            <label class="margin-t-10" style="font-size:18px;color: #0000ffad;">Features</label>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox1" type="checkbox" name="check1[]" value="freeparking">
                                <label for="checkbox1">
                                    Free Parking
                                </label>
                            </div>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox2" type="checkbox" name="check1[]" value="aircondition">
                                <label for="checkbox2">
                                    Air Condition
                                </label>
                            </div>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox3" type="checkbox" name="check1[]" value="placetoseat">
                                <label for="checkbox3">
                                    Places to seat
                                </label>
                            </div>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox4" type="checkbox" name="check1[]" value="swimmingpool">
                                <label for="checkbox4">
                                    Swimming Pool
                                </label>
                            </div>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox5" type="checkbox" name="check1[]" value="laundryroom">
                                <label for="checkbox5">
                                    Laundry Room
                                </label>
                            </div>
                            <div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox6" type="checkbox" name="check1[]" value="Garden">
                                <label for="checkbox6">
                                    Garden
                                </label>
                            </div>
                            
							<div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox9" type="checkbox" name="check1[]" value="lift">
                                <label for="checkbox9">
                                    Lift
                                </label>
                            </div>
							<div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox10" type="checkbox" name="check1[]" value="gas">
                                <label for="checkbox10">
                                    Piped Gas
                                </label>
                            </div>
							<div class="checkbox checkbox-theme checkbox-circle">
                                <input id="checkbox11" type="checkbox" name="check1[]" value="gym">
									<label for="checkbox11">
									GYM
									</label>
                                </div>
                        </div>
                        <div class="form-group">
                            <button class="search-button" type="submit">Search</button>
                        </div>
                    </form>
                </div>
                 <!-- Search contents sidebar end -->

                <!-- Helping Center Start -->
                <div class="sidebar sidebar-widget helping-center">
                    <h3 class="title">Helping Center</h3>
                    <p></p>
                    <ul class="contact-link">
                        <li>
                            <i class="fa fa-map-marker"></i>
                            
                        </li>
                        <li>
                            <i class="fa fa-phone"></i>
                            <a href="tel:+55-417-634-7071">
                                
                            </a>
                        </li>
                        <li>
                            <i class="fa fa-envelope-o"></i>
                            <a href="mailto:info@themevessel.com">
                                info@homy.com
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- Helping Center Start -->
            </div>
        </div>
    </div>
</div>

<?php
include("include/footer.php");
?>
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-list-leftsidebar.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:23 GMT -->
</html>