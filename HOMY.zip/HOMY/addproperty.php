<?php

include("include/header.php");

$con=mysqli_connect('localhost','root','','property') or die(mysqli_error());
if(isset($_POST['submit']))
{
	$id=$_SESSION['id'];
		
	$propertytitle=$_POST['propertytitle'];
	$propertystatus=$_POST['propertystatus1'];
	$category=$_POST['category'];
	$subcategory=$_POST['subcategory'];
	$minprice=$_POST['minprice'];
	$maxprice=$_POST['maxprice'];
	$minarea=$_POST['minarea'];
	$maxarea=$_POST['maxarea'];
	$rooms=$_POST['rooms'];
	$bathrooms=$_POST['bathrooms'];
	$balconey=$_POST['Balconey1'];
	$furnished=$_POST['Furnished1'];
	$floor=$_POST['floor'];
	$cons_status=$_POST['con_status'];
	$date=$_POST['date'];
	
	$count=count($_FILES['img']['name']);
		
		$file_array = array();
		for($i=0 ; $i<$count ; $i++)
		{			
			$name = $_FILES['img']['name'][$i];
			$src_path = $_FILES['img']['tmp_name'][$i];
			$dest_path = "../minimaladmin/images/propertyimg/".rand(0,100000000).$name ; 
			array_push($file_array , $dest_path);
			move_uploaded_file($src_path,$dest_path);		
		}    
	$final_dest_path=implode(',',$file_array);
		
	$floorno=$_POST['floorno'];
	$complexname=$_POST['complexname'];
	$city=$_POST['city'];
	$area=$_POST['area'];
	$postalcode=$_POST['postalcode'];
	$description=mysqli_real_escape_string($con,$_POST['description']);
	$feature=$_POST['check'];
	$a=implode(',',$feature);	
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	
	$query="insert into propertydetail values('','$propertytitle','$propertystatus','$category','$subcategory','$minprice','$maxprice','$minarea','$maxarea','$rooms','$bathrooms','$balconey','$furnished','$floor','$cons_status','$date','$final_dest_path','$floorno','$complexname','$city','$area','$postalcode','$description','$a','$id','$email','$phone')";
	$result=mysqli_query($con,$query);
	
	$msg="Property Upload Succesfully...";
}
if(isset($_GET['did']))
{
	$id=$_GET['did'];
	
	$result1=mysqli_query($con,"select * from propertydetail where propertydetail_id='$id'");
	$row9=mysqli_fetch_array($result1);
		
		$img1=explode(',', $row9['photo']);
			$number_of_photos_delete = count($img1);
						
			for ($i2=0; $i2<$number_of_photos_delete; $i2++) 
			{			
				unlink($img1[$i2]);
			}
	
	$query="delete from propertydetail where propertydetail_id='$id'";
	mysqli_query($con,$query);
	?>
	<script type="text/javascript">
		window.location="myproperties.php";
    </script>
	<?php
}
if(isset($_GET['eid']))
{
	$id=$_GET['eid'];
		
	$query="select * from propertydetail where propertydetail_id='$id'";
	$result=mysqli_query($con,$query);
	$row16=mysqli_fetch_array($result);
	
	$check=explode(',',$row16['features']);
}
if(isset($_POST['edit']))
{
	$id=$_GET['eid'];
	
			$query_delete="select * from propertydetail where propertydetail_id='$id'";
			$result_delete=mysqli_query($con,$query_delete);
			$row_delete = mysqli_fetch_array($result_delete);
			$img1=explode(',', $row_delete['photo']);
			$number_of_photos_delete = count($img1);
											
			for ($i2=0; $i2<$number_of_photos_delete; $i2++) 
			{			
				unlink($img1[$i2]);
			}		
	$propertytitle=$_POST['propertytitle'];
	$propertystatus=$_POST['propertystatus1'];
	$category=$_POST['category'];
	$subcategory=$_POST['subcategory'];
	$minprice=$_POST['minprice'];
	$maxprice=$_POST['maxprice'];
	$minarea=$_POST['minarea'];
	$maxarea=$_POST['maxarea'];
	$rooms=$_POST['rooms'];
	$bathrooms=$_POST['bathrooms'];
	$balconey=$_POST['Balconey1'];
	$furnished=$_POST['Furnished1'];
	$floor=$_POST['floor'];
	$cons_status=$_POST['con_status'];
	$date=$_POST['date'];
	
	$count=count($_FILES['img']['name']);
		
		$file_array = array();
		for($i=0 ; $i<$count ; $i++)
		{			
			$name = $_FILES['img']['name'][$i];
			$src_path = $_FILES['img']['tmp_name'][$i];
			$dest_path = "../minimaladmin/images/propertyimg/".rand(0,100000000).$name ; 
			array_push($file_array , $dest_path);
			move_uploaded_file($src_path,$dest_path);		
		}    
	$final_dest_path=implode(',',$file_array);
		
	$floorno=$_POST['floorno'];
	$complexname=$_POST['complexname'];
	$city=$_POST['city'];
	$area=$_POST['area'];
	$postalcode=$_POST['postalcode'];
	$description=mysqli_real_escape_string($con,$_POST['description']);
	$feature=$_POST['check'];
	$a=implode(',',$feature);	
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	
	$query="update  propertydetail set propertystatus_id='$propertystatus',propertytitle='$propertytitle',category_id='$category',subcat_id='$subcategory',minprice='$minprice',maxprice='$maxprice',minarea='$minarea',maxarea='$maxarea',rooms='$rooms',bathrooms='$bathrooms',balconey='$balconey',furnished_id='$furnished',floor='$floor',cons_status='$cons_status',date='$date',photo='$final_dest_path',floorno='$floorno',complexname='$complexname',cityid='$city',area_id='$area',postalcode='$postalcode',description='$description',features='$a',email='$email',phone='$phone' where propertydetail_id='$id'";
	mysqli_query($con,$query);
	?>
	<script type="text/javascript">
		window.location="myproperties.php";
    </script>
	<?php	
}
?>
<!DOCTYPE html>
<html lang="zxx">
<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/submit-property.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:10 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

	
	<script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
      <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
      
      <!-- Javascript -->
      <script>
         $(function() {
            $( "#datepicker-12" ).datepicker();
            $( "#datepicker-12" ).datepicker("setDate", "10w+1");
         });
      </script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>
<!-- Option Panel -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>Submit Property</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Submit Property</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->
<!-- Submit Property start -->
<div class="
submit-property">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="submit-address">
					<?php if(isset($msg))
					{
						?>
						<center ><h1 style="font-size:18px;color:green;"><?php echo $msg; ?></h1></center>
						<?php
					} ?>
                    <form action="" method="post" enctype="multipart/form-data" name="myForm" onsubmit="return(validate());">
                        <h1>Upload Property</h1>
                        <div class="search-contents-sidebar" style="font-size:18px;">
                            <div class="form-group">
                                <label>Property Title</label> <span style="color:red;font-size: 12px;" id="propertytitle1"></span>
                                <input type="text" class="input-text" name="propertytitle" value="<?php if(isset($_GET['eid'])){ echo $row16['propertytitle'];} ?>" placeholder="Property Title">
                            
							</div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Status</label>
										<?php
											$query="select * from propertystatus";
											$result=mysqli_query($con,$query);
										?>
                                        <select class="selectpicker search-fields" name="propertystatus1" id="propertystatus1">
										<option>Select Property Status</option>
										<?php
											while($row1=mysqli_fetch_array($result))
											{
										?>
                                            <option <?php if(isset($_GET['eid'])){ if($row1['propertystatus_id']==$row16['propertystatus_id']){ echo "selected='selected'";}} ?> value="<?php echo $row1['propertystatus_id']; ?>"><?php echo $row1['propertystatus']; ?></option>
                                         <?php
											}
										?>										 
                                        </select>
										<span style="color:red;font-size: 10px;" id="propertystatus2"></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Type</label>
										<?php
											$query="select * from p_category";
											$result=mysqli_query($con,$query);
										?>
                                        <select class="selectpicker search-fields" name="category" id="category1" onchange="pro_category1(this.value)">
                                            <option>Select Property Type</option>
                                        <?php
											while($row2=mysqli_fetch_array($result))
											{
										?>
											<option <?php if(isset($_GET['eid'])){ if($row2['category_id']==$row16['category_id']){ echo "selected='selected'";}} ?> value="<?php echo $row2['category_id']; ?>"><?php echo $row2['categoryname']; ?></option>
										<?php
											}
										?>
                                        </select>
										<span style="color:red;font-size: 10px;" id="category2"></span>
                                    </div>
                                </div>
								<?php
									if(isset($_GET['eid']))
									{
										$query="select * from  p_subcategory";
										$result=mysqli_query($con,$query);
								?>
								<div class="col-md-4">
                                    <div class="form-group">
                                        <label>BHK</label>										
										<select class="btn-group bootstrap-select  search-fields" name="subcategory" id="demo1">
											<option>Select Property BHK</option>
											<?php
												while($row13=mysqli_fetch_array($result))
												{
											?>
											<option <?php if(isset($_GET['eid'])){ if($row13['subcat_id']==$row16['subcat_id']){ echo "selected='selected'";}} ?> value="<?php echo $row13['subcat_id'];?>"><?php echo $row13['subcategory']; ?></option>
											<?php
												}
											?>	
									</select>
									<span style="color:red;font-size: 10px;" id="subcategory2"></span>
                                    </div>
                                </div>
								<?php
									}else{
								?>
								<div class="col-md-4">
                                    <div class="form-group">
                                        <label>BHK</label>										
										<select class="btn-group bootstrap-select  search-fields" name="subcategory" id="demo1">
											<option>Select Property BHK</option>
											
									</select>
									<span style="color:red;font-size: 10px;" id="subcategory2"></span>
                                    </div>
                                </div>
								<?php
									}
								?>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Min Price (optional)</label>
                                        <input type="text" class="input-text" value="<?php if(isset($_GET['eid'])){ echo $row16['minprice'];}?>" name="minprice" placeholder="INR">
                                    </div>
								</div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>Max Price</label> <span style="color:red;font-size: 10px;" id="maxprice2"></span>
										
                                        <input type="text" class="input-text" value="<?php if(isset($_GET['eid'])){ echo $row16['maxprice'];}?>" name="maxprice" placeholder="INR">
                                    
									</div>
								</div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Min Area SqFt</label> <span style="color:red;font-size: 10px;" id="minarea1"></span>
                                        <input type="text" class="input-text" value="<?php if(isset($_GET['eid'])){ echo $row16['minarea'];}?>" name="minarea" placeholder="SqFt">
                                    
									</div>
                                </div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>Max Area SqFt</label> <span style="color:red;font-size: 10px;" id="maxarea1"></span>
                                        <input type="text" class="input-text" value="<?php if(isset($_GET['eid'])){ echo $row16['maxarea'];}?>" name="maxarea" placeholder="SqFt">
                                    
									</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Rooms</label> <span style="color:red;font-size: 10px;" id="rooms1"></span>
                                        <input type="text" class="input-text" name="rooms" value="<?php if(isset($_GET['eid'])){ echo $row16['rooms'];}?>" placeholder="Enter Rooms">
                                    
									</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Bathroom</label> <span style="color:red;font-size: 10px;" id="bathrooms1"></span>
                                        <input type="text" class="input-text" name="bathrooms" value="<?php if(isset($_GET['eid'])){ echo $row16['bathrooms'];}?>" placeholder="Enter BathRooms">
                                    
									</div>
                                </div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>Balconey</label> <span style="color:red;font-size: 10px;" id="balconey12"></span>
                                        <input type="text" class="input-text" name="Balconey1" value="<?php if(isset($_GET['eid'])){ echo $row16['balconey'];}?>" placeholder="Enter Balconey">
                                    
									</div>
                                </div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>furnished</label>
										<?php
											$query="select * from furnished";
											$result22=mysqli_query($con,$query);
										?>
                                        <select class="selectpicker search-fields" name="Furnished1" id="furnished1">
                                            <option>Select furnished</option>
                                        <?php
											while($row22=mysqli_fetch_array($result22))
											{
										?>
											<option  <?php if(isset($_GET['eid'])){ if($row22['furnished_id']==$row16['furnished_id']){ echo "selected='selected'";}}?> value="<?php echo $row22['furnished_id']; ?>"><?php echo $row22['furnished']; ?></option>
										<?php
											}
										?>
                                        </select>
										 <span style="color:red;font-size: 10px;" id="furnished2"></span>
                                    </div>
                                </div>
								
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>Floor</label>
                                        <input type="text" class="input-text" value="<?php if(isset($_GET['eid'])){ echo $row16['floor'];}?>"  name="floor" placeholder="Enter Floor">
                                    <span style="color:red;font-size: 10px;" id="floor1"></span>
									</div>
                                </div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>con_status</label>
                                        <input type="text" class="input-text" name="con_status" value="<?php if(isset($_GET['eid'])){ echo $row16['cons_status'];}?>" placeholder="Enter con_status">
                                    <span style="color:red;font-size: 10px;" " id="cons_status1"></span>
									</div>
                                </div>
								<div class="col-md-3">
                                    <div class="form-group">
                                        <label>Date OF Post (DD-MM-YYYY)</label>
                                        <input type="date" class="input-text" id = "datepicker-12" name="date" value="" placeholder="Enter Date of post"><?php if(isset($_GET['eid'])){ echo $row16['date'];}?>
                                    <span style="color:red;font-size: 10px;" " id="date1"></span>
									</div>
                                </div>
                            </div>
                        </div>
                        <h1>Property Photo</h1>
						<?php
						if(isset($_GET['eid']))
						{
							$img=explode(',', $row16['photo']);
							$number_of_photos = count($img);
									 
							$flag = 0;
							for ($i1=0; $i1<$number_of_photos; $i1++) 
							{
								if($flag==0)
								{							
						?>
						<div >
							<img src="<?php echo $img[$i1];?>" width="150" align="right">
						</div>
								<?php
							}								
						}								
						?>
						<div >
							<input type="file" name="img[]" id="img" multiple style="font-size:25px;">
							<span style="color:red;" id="photo1"></span>
						</div>
						<?php
						}
						else
						{
						?>
						<div >
							<input type="file" name="img[]" id="img" multiple style="font-size:25px;">
						<span style="color:red;" id="photo1"></span>
						</div>
						<?php
						}
						?>
                        <h1>Location</h1>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Floor No</label> <span style="color:red;font-size: 10px;"  id="floorno12"></span>
									<input type="text" class="input-text" name="floorno" value="<?php if(isset($_GET['eid'])){ echo $row16['floorno'];}?>" placeholder="Enter floorno">
								
								</div>								
							</div>
							<div class="col-md-6">
								<div class="form-group">
								<label>Complex Name</label> <span style="color:red;font-size: 10px;" id="complexname1"></span>
									<input type="text" class="input-text" name="complexname" value="<?php if(isset($_GET['eid'])){ echo $row16['complexname'];}?>" placeholder="Enter complexname">
								
								</div>
							</div>
							<div class="col-md-6">
                                <div class="form-group">
                                    <label>Area</label>
									<?php
										$query="select * from area";
										$result=mysqli_query($con,$query);
									?>									
                                    <select class="selectpicker search-fields" name="area"  id="area1" data-live-search="true" data-live-search-placeholder="Search value">
                                        <option hidden>Choose Any Area</option>
                                    <?php
										while($row3=mysqli_fetch_array($result))
										{
									?>
										<option <?php if(isset($_GET['eid'])){ if($row3['area_id']==$row16['area_id']){ echo "selected='selected'";}}?> value="<?php echo $row3['area_id'];?>"><?php echo $row3['areaname']; ?></option>
									<?php
										}
									?>   
                                    </select>
									<span style="color:red;font-size: 10px;" id="area2"></span>
                                </div>
                            </div>
                            <div class="col-md-6">							
                                <div class="form-group">
                                    <label>City</label>
									<?php
										$query="select * from city";
										$result=mysqli_query($con,$query);
									?>	
                                    <select class="selectpicker search-fields" name="city" id="city1" data-live-search="true" data-live-search-placeholder="Search value">
                                        <option hidden>Choose Any City</option>
                                    <?php
										while($row4=mysqli_fetch_array($result))
										{
									?>
									<option <?php if(isset($_GET['eid'])){ if($row4['cityid']==$row16['cityid']){ echo "selected='selected'";}}?> value="<?php echo $row4['cityid']; ?>"> <?php echo $row4['cityname']; ?></option>
									<?php
										}
									?>   
                                    </select>
									<span style="color:red;font-size: 10px;" id="city2"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Postal Code</label>
                                    <input type="text" class="input-text" name="postalcode" value="<?php if(isset($_GET['eid'])){ echo $row16['postalcode'];}?>"  placeholder="Enter Postal Code">
                                <span style="color:red;font-size: 15px;" id="postalcode1"></span>
								</div>
                            </div>
                        </div>
                        <h1>Detailed Information</h1>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Detailed Information</label>
                                    <textarea class="input-text" name="description" placeholder="Detailed Information"><?php if(isset($_GET['eid'])){ echo $row16['description'];}?></textarea>
                                <span style="color:red;" id="description1"></span>
								</div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <label class="margin-t-10">Features </label>
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox1"  type="checkbox" required name="check[]" value="freeparking" <?php if(isset($_GET['eid'])){ if(in_array('freeparking',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox1">
                                                Free Parking
                                            </label>
                                        </div>
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox2" type="checkbox" name="check[]" value="aircondition" <?php if(isset($_GET['eid'])){ if(in_array('aircondition',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox2">
                                                Air Condition
                                            </label>
                                        </div>
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox3" type="checkbox" name="check[]" value="placetoseat" <?php if(isset($_GET['eid'])){ if(in_array('placetoseat',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox3">
                                                Places to seat
                                            </label>
                                        </div>
										
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox4" type="checkbox" name="check[]" value="swimmingpool" <?php if(isset($_GET['eid'])){ if(in_array('swimmingpool',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox4">
                                                Swimming Pool
                                            </label>
                                        </div>
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox5" type="checkbox" name="check[]" value="laundryroom" <?php if(isset($_GET['eid'])){ if(in_array('laundryroom',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox5">
                                                Laundry Room
                                            </label>
                                        </div>
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox6" type="checkbox" name="check[]" value="Garden" <?php if(isset($_GET['eid'])){ if(in_array('Garden',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox6">
                                                Garden
                                            </label>
                                        </div>
										
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox12" type="checkbox" name="check[]" value="gas" <?php if(isset($_GET['eid'])){ if(in_array('gas',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox12">
                                                Piped Gas
                                            </label>
                                        </div>
										<div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox9" type="checkbox" name="check[]" value="gym" <?php if(isset($_GET['eid'])){ if(in_array('gym',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox9">
                                                GYM
                                            </label>
                                        </div>
										<div class="checkbox checkbox-theme checkbox-circle">
                                            <input id="checkbox10" type="checkbox" name="check[]" value="lift" <?php if(isset($_GET['eid'])){ if(in_array('lift',$check)){ echo "checked='checked'";}}?>>
                                            <label for="checkbox10">
                                                Lift
                                            </label>
                                        </div>
                                    </div>
									
                                </div>
                            </div>
                        </div>
						<?php
						$id=$_SESSION['id'];
						$query="select * from signup where signup_id='$id'";
						$result=mysqli_query($con,$query);
						$row2=mysqli_fetch_array($result);
						?>
                        <h1>Contact Details</h1>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="input-text" readonly value="<?php echo $row2['name'];?>" name="name" placeholder="Enter Name">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="input-text" value="<?php echo $row2['email'];?>" name="email" placeholder="Enter Email">
                                <span style="color:red;" id="email"></span>
								</div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Phone </label>
                                    <input type="text" class="input-text" value="<?php echo $row2['mobile'];?>" name="phone"  placeholder="Enter Phoneno">
                                <span style="color:red;" id="phone"></span>
								</div>
                            </div>
                            <div class="col-md-12">
								<button type="submit" name="<?php if(isset($_GET['eid'])){ echo "edit";} else{ echo "submit";} ?>" class="btn button-md button-theme"><?php if(isset($_GET['eid'])){ echo "Edit";} else{ echo "Submit";} ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Submit Property end -->

<!-- Partners block start -->
<div class="partners-block">
    
</div>
<!-- Partners block end -->
<?php
include("include/footer.php");
?>
<script type="text/javascript">
function validate()
      {
		
		var propertytitle = document.myForm.propertytitle.value;
		var maxprice = document.myForm.maxprice.value;
		var minarea = document.myForm.minarea.value;
		var maxarea = document.myForm.maxarea.value;
		var rooms = document.myForm.rooms.value;
		var bathrooms = document.myForm.bathrooms.value;
		var balconey = document.myForm.Balconey1.value;		
		var floor = document.myForm.floor.value;
		var cons_status = document.myForm.con_status.value;
		var date = document.myForm.date.value;
		var floorno = document.myForm.floorno.value;		
		var complexname = document.myForm.complexname.value;
		var postalcode = document.myForm.postalcode.value;
		var description = document.myForm.description.value;
		var email = document.myForm.email.value;
		var phone = document.myForm.phone.value;	
		
		
		if(propertytitle == "")
		 {
		 document.getElementById("propertytitle1").innerHTML="Please Fill propertytitle Filed.";
		 document.myForm.propertytitle.focus() ;
            return false;
         }
		 else{
			 document.getElementById("propertytitle1").innerHTML="";
		 }	 
		if(maxprice == "")
		 {			 
		 document.getElementById("maxprice2").innerHTML="Please Fill maxprice Filed.";
		 document.myForm.maxprice.focus() ;
            return false;
         }
		 else{
			 document.getElementById("maxprice2").innerHTML="";
		 }
		 if(isNaN(maxprice))
		 {
			document.getElementById("maxprice2").innerHTML="User Must Enter Digit";
            document.myForm.maxprice.focus() ;
            return false;
		 }
		 else{
			document.getElementById("maxprice2").innerHTML=""; 
		 }
		 if(minarea == "")
		 {			 
		 document.getElementById("minarea1").innerHTML="Please Fill minarea Filed.";
		 document.myForm.minarea.focus() ;
            return false;
         }
		 else{
			 document.getElementById("minarea1").innerHTML="";
		 }	
		if(isNaN(minarea))
		 {
			document.getElementById("minarea1").innerHTML="User Must Enter Digit";
            document.myForm.minarea.focus() ;
            return false;
		 }
		 else{
			document.getElementById("minarea1").innerHTML=""; 
		 }
		 		 if(maxarea == "")
		 {			 
		 document.getElementById("maxarea1").innerHTML="Please Fill maxarea Filed.";
		 document.myForm.maxarea.focus() ;
            return false;
         }
		 else{
			 document.getElementById("maxarea1").innerHTML="";
		 }	
		if(isNaN(maxarea))
		 {
			document.getElementById("maxarea1").innerHTML="User Must Enter Digit";
            document.myForm.maxarea.focus() ;
            return false;
		 }
		 else{
			document.getElementById("maxarea1").innerHTML=""; 
		 }
		  if(rooms == "")
		 {			 
		 document.getElementById("rooms1").innerHTML="Please Fill rooms Filed.";
		 document.myForm.rooms.focus() ;
            return false;
         }
		 else{
			 document.getElementById("rooms1").innerHTML="";
		 }	
		if(isNaN(rooms))
		 {
			document.getElementById("rooms1").innerHTML="User Must Enter Digit";
            document.myForm.rooms.focus() ;
            return false;
		 }
		 else{
			document.getElementById("rooms1").innerHTML=""; 
		 }
		  if(bathrooms == "")
		 {			 
		 document.getElementById("bathrooms1").innerHTML="Please Fill bathrooms Filed.";
		 document.myForm.bathrooms.focus() ;
            return false;
         }
		 else{
			 document.getElementById("bathrooms1").innerHTML="";
		 }	
		if(isNaN(bathrooms))
		 {
			document.getElementById("bathrooms1").innerHTML="User Must Enter Digit";
            document.myForm.bathrooms.focus() ;
            return false;
		 }
		 else{
			document.getElementById("bathrooms1").innerHTML=""; 
		 }
		  if(balconey == "")
		 {
			 
		 document.getElementById("balconey12").innerHTML="Please Fill balconey Filed.";
		 document.myForm.Balconey1.focus() ;
            return false;
         }
		 else{
			 document.getElementById("balconey12").innerHTML="";
		 }	
		if(isNaN(balconey))
		 {
			document.getElementById("balconey12").innerHTML="User Must Enter Digit";
            document.myForm.Balconey1.focus() ;
            return false;
		 }
		 else{
			document.getElementById("balconey12").innerHTML=""; 
		 }
		   if(floor == "")
		 {			 
		 document.getElementById("floor1").innerHTML="Please Fill floor Filed.";
		 document.myForm.floor.focus() ;
            return false;
         }
		 else{
			 document.getElementById("floor1").innerHTML="";
		 }	
		if(isNaN(floor))
		 {
			document.getElementById("floor1").innerHTML="User Must Enter Digit";
            document.myForm.floor.focus() ;
            return false;
		 }
		 else{
			document.getElementById("floor1").innerHTML=""; 
		 }
		 if(cons_status == "")
		 {
		 document.getElementById("cons_status1").innerHTML="Please Fill cons_status Filed.";
		 document.myForm.con_status.focus() ;
            return false;
         }
		 else{
			 document.getElementById("cons_status1").innerHTML="";
		 }
		  if(date == "")
		 {
		 document.getElementById("date1").innerHTML="Please Fill date Filed. DD-MM-YYYY";
		 document.myForm.date.focus() ;
            return false;
         }
		 else{
			 document.getElementById("date1").innerHTML="";
		 }
		 if(floorno == "")
		 {
		 document.getElementById("floorno12").innerHTML="Please Fill floorno Filed.";
		 document.myForm.floorno.focus() ;
            return false;
         }
		 else{
			 document.getElementById("floorno12").innerHTML="";
		 }
		 if(complexname == "")
		 {
		 document.getElementById("complexname1").innerHTML="Please Fill complexname Filed.";
		 document.myForm.complexname.focus() ;
            return false;
         }
		 else{
			 document.getElementById("complexname1").innerHTML="";
		 }
		  if(postalcode == "")
		 {
		 document.getElementById("postalcode1").innerHTML="Please Fill postalcode Filed.";
		 document.myForm.postalcode.focus() ;
            return false;
         }
		 else{
			 document.getElementById("postalcode1").innerHTML="";
		 }
		 if(postalcode.length !=6)
		 {
			document.getElementById("postalcode1").innerHTML="postalcode Must Write 6 digit";
            document.myForm.postalcode.focus() ;
            return false;
		 }
		 else{
			document.getElementById("postalcode1").innerHTML=""; 
		 }
		if(isNaN(postalcode))
		 {
			document.getElementById("postalcode1").innerHTML="User Must Enter Digit";
            document.myForm.postalcode.focus() ;
            return false;
		 }
		 else{
			document.getElementById("postalcode1").innerHTML=""; 
		 }
		 if(description == "")
		 {
		 document.getElementById("description1").innerHTML="Please Fill description Filed.";
		 document.myForm.description.focus() ;
            return false;
         }
		 else{
			 document.getElementById("description1").innerHTML="";
		 }
		if( email == "" )
         {
            document.getElementById("email").innerHTML="Please Fill the Email field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.length <= 2) || (email.length > 25) )
		 {
			document.getElementById("email").innerHTML="user length must be between 2 and 25";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email").innerHTML="";
		 } 		
		 if( phone == "")
		 {
			document.getElementById("phone").innerHTML="Please Fill the phone field";
            document.myForm.phone.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		 if(isNaN(phone))
		 {
			document.getElementById("phone").innerHTML="User Must Enter Digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		 if(phone.length !=10)
		 {
			document.getElementById("phone").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		 var e = document.getElementById("propertystatus1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select Property Status" )
		{
			document.getElementById("propertystatus2").innerHTML="Please Select propertystatus Filed.";
			return false;
			
		}else{
				document.getElementById("propertystatus2").innerHTML="";
			}	
		var e = document.getElementById("category1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select Property Type" )
		{
			
			document.getElementById("category2").innerHTML="Please Select category Filed.";
			return false;
			
		}else{
				document.getElementById("category2").innerHTML="";
			}
		var e = document.getElementById("furnished1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;	
		
		if(strUser==0 || strUser == "Select furnished" )
		{
			document.getElementById("furnished2").innerHTML="Please Select furnished Filed.";
			return false;
			
		}else{
				document.getElementById("furnished2").innerHTML="";
			}			
		var e = document.getElementById("city1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;		
		
		if(strUser==0 || strUser == "Choose Any City" )
		{
			document.getElementById("city2").innerHTML="Please Select city Filed.";
			return false;
			
		}else{
				document.getElementById("city2").innerHTML="";
			}
			var e = document.getElementById("area1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Choose Any Area" )
		{
			document.getElementById("area2").innerHTML="Please Select subcategory Filed.";
			return false;
			
		}else{
				document.getElementById("area2").innerHTML="";
			}
		var e = document.getElementById("demo1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select Property BHK" )
		{
			document.getElementById("subcategory2").innerHTML="Please Select subcategory Filed.";
			return false;
			
		}else{
				document.getElementById("subcategory2").innerHTML="";
			}
			
		var fup = document.getElementById('img');
		var fileName = fup.value;
		var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
		
		if(ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG")
		{
			return true;
		} 
		else
		{			
			document.getElementById("photo1").innerHTML="Upload jpeg or Jpg images only";
			fup.focus();
			return false;
		}
		 	 return( true );
	  }
</script>
<!-- Sub footer end -->
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
 
		function pro_category1(str)
			{
				var xhttp;
				if(window.XMLHttpRequest)
				{
					xhttp= new XMLHttpRequest();
				}
				else
				{
					xhttp= new ActiveXObject("Microsoft.XMLHTTP");
				}
				
				xhttp.onreadystatechange=function()
				{
					if(this.readyState == 4 && this.status == 200)
					{
						document.getElementById("demo1").innerHTML=this.responseText;
					}
				};
								
				xhttp.open("GET","propertyajaxdropdown.php?data1="+str,true);
				xhttp.send();
			}

 </script>
</body>
<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/submit-property.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:10 GMT -->
</html>
