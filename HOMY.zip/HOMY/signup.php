<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
if(isset($_POST['submit']))
{
	$name=$_POST['fullname'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$cpassword=$_POST['cpassword'];
	$mobile=$_POST['mobile'];
	$usertype=$_POST['usertype'];
	
	$query="insert into signup values('','$name','$email','$password','$cpassword','$mobile','$usertype')";
	mysqli_query($con,$query);
	
	$msg="Registration Succesfully...";
}
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/signup.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:12 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="form-page-body" background="img/1.jpg"; style="background-repeat: no-repeat; background-size:cover;">
<div class="page_loader"></div>
<!-- Option Panel -->

<!-- /Option Panel -->

<div class="container">
        <div class="row">
        <div class="col-lg-12">
            <!-- Form content box start -->
			
            <div class="form-content-box" style="margin-top:12px;">
                <!-- details -->
                <div class="details">
                    <!-- Logo-->
                    <a href="index.php">
                        <img src="img/black-logo.png" class="cm-logo" alt="black-logo">
                    </a>
                    <!-- Name -->
                    <h3>Signup</h3>
                    <!-- Divider -->
                    <div class="divider">
                        <span class="or-text">OR</span>
                    </div>
						<?php
						if(isset($msg))
						{
						?>
							<center ><h1 style="font-size: 18px;color: yellow;"><?php echo $msg; ?></h1></center>
							<?php
						}
						?>
                    <!-- Form start-->
                    <form action="" method="post" name="myForm" onsubmit="return(validate());">
                        <div class="form-group">
                            <input type="text" name="fullname" class="input-text" placeholder="Full Name">
                        <span style="color:red;font-size: 18px;" id="name"></span>
						</div>
                        <div class="form-group">
                            <input type="text" name="email" class="input-text" placeholder="Email Address">
						<span id="emailcheck1"></span>
						<span style="color:red;font-size: 18px;" id="email">
						</div>
                        <div class="form-group">
                            <input type="password" name="password" class="input-text" placeholder="Password">
						<span style="color:red;font-size: 18px;" id="password">
						</div>
						 <div class="form-group">
                            <input type="password" name="cpassword" class="input-text" placeholder="conform Password">
                        <span style="color:red;font-size: 18px;" id="cpassword1">
						</div>                        
						<div class="form-group">
                            <input type="text" name="mobile" class="input-text" placeholder="Mobileno">
                        <span style="color:red;font-size: 18px;" id="mobile">
						</div>
											
						<div class="form-group"style="font-size:18px;">
							  <input name="usertype" value="Buyer" type="radio" id="buyer" /> Buyer / Owner
							  <input name="usertype" value="Builder" type="radio" id="builder"  /> Builder  
							  <input name="usertype" value="Agent" type="radio" id="agent" />  Agent
						<br><span style="color:red;font-size: 18px;" id="radion1">
						</div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="button-md button-theme btn-block">Signup</button>
                        </div>
                    </form>
                    <!-- Form end-->
                </div>
                <!-- Footer -->
               <div class="footer">
                    <span>
                        I want to <a href="login.php">return to login</a>
                    </span>
                </div>
            </div>
            <!-- Form content box end -->
        </div>
    </div>
    </div>

<script type="text/javascript">
function validate()
      {
		  var name = document.myForm.fullname.value;
		  var email = document.myForm.email.value;
		  var pass = document.myForm.password.value;
		  var cpass = document.myForm.cpassword.value;
		  var mobile = document.myForm.mobile.value;
		   var radio = document.myForm.usertype.checked;		 
		 
		 if(name == "")
		 {
		 document.getElementById("name").innerHTML="Please Fill Name Filed.";
		 document.myForm.fullname.focus() ;
            return false;
         }
		 else{
			 document.getElementById("name").innerHTML="";
		 }
		 
		 if( email == "" )
         {
            document.getElementById("email").innerHTML="Please Fill the username field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.length <= 5) || (email.length > 25) )
		 {
			document.getElementById("email").innerHTML="user length must be between 5 and 25";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email").innerHTML="";
		 }
		 
		if( pass == "" )
         {
            document.getElementById("password").innerHTML="Please Fill the password field";
            document.myForm.password.focus() ;
            return false;
         }
		 else{
			document.getElementById("password").innerHTML=""; 
		 }
		 if((pass.length <= 5) || (pass.length > 20) )
		 {
			document.getElementById("password").innerHTML="password length must be between 5 and 20";
            document.myForm.password.focus() ;
            return false;
		 }	
		else{
			document.getElementById("password").innerHTML=""; 
		 }
		 if( cpass == "")
		 {			
			document.getElementById("cpassword1").innerHTML="Please Fill the conformpassword field";
            document.myForm.cpassword.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("cpassword1").innerHTML=""; 
		 }
		 if( pass != cpass)
		 {
			document.getElementById("cpassword1").innerHTML="password and conform password Not Same";
            document.myForm.cpassword.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("cpassword1").innerHTML=""; 
		 }
		 if( mobile == "")
		 {
			document.getElementById("mobile").innerHTML="Please Fill the Mobile field";
            document.myForm.mobile.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(isNaN(mobile))
		 {
			document.getElementById("mobile").innerHTML="User Must Enter Digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(mobile.length !=10)
		 {
			document.getElementById("mobile").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(document.getElementById('buyer').checked || document.getElementById('builder').checked || document.getElementById('agent').checked ) {
			//Male radio button is checked
			
		}else  {
			document.getElementById("radion1").innerHTML="Please Fill the One CheckBox field";
            //document.myForm.radio.focus() ;
			return false ;
		}
		 return( true );
	  }
</script>

	
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/signup.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:12 GMT -->
</html>