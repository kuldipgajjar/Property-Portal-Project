<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-grid-leftside.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:24 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>
<?php
include("include/header.php");
?>
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>Properties Grid Leftside</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Properties Grid Leftside</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Properties section body start -->
<div class="properties-section-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12 col-md-push-4">
                <!-- Option bar start -->
                <div class="option-bar">
                    <div class="row">
                        <div class="col-lg-6 col-md-5 col-sm-5 col-xs-2">
                            <h4>
                                <span class="heading-icon">
                                    <i class="fa fa-th-large"></i>
                                </span>
                                <span class="hidden-xs">Properties Grid</span>
                            </h4>
                        </div>
                        <div class="col-lg-6 col-md-7 col-sm-7 col-xs-10 cod-pad">
                            <div class="sorting-options">
                                <select class="sorting">
                                    <option>Price High to Low</option>
                                    <option>Price: Low to High</option>
                                    <option>Newest Properties</option>
                                    <option>Oldest Properties</option>
                                </select>
                                <a href="propertieslistleftsidebar.php" class="change-view-btn"><i class="fa fa-th-list"></i></a>
                                <a href="propertiesgridleftside.php" class="change-view-btn active-view-btn"><i class="fa fa-th-large"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Option bar end -->
				
                <div class="clearfix"></div>

                <div class="row">
                   <?php
				 if(isset($_GET['submit']))
				{
					$area=$_GET['area'];
					$propertystatus=$_GET['propertystatus'];
					$category=$_GET['category'];
					$minprice=$_GET['minprice'];
					$maxprice=$_GET['maxprice'];
				
				$query="select * from propertydetail,propertystatus where area_id='$area' AND propertystatus.propertystatus_id='$propertystatus' AND category_id='$category'AND minprice >= $minprice AND maxprice <= $maxprice AND propertydetail.propertystatus_id=propertystatus.propertystatus_id ";
				$result=mysqli_query($con,$query);
				while($row=mysqli_fetch_array($result))
				{
				?>
                    <div class="col-lg-6 col-md-6 col-sm-6 wow fadeInUp delay-03s" >
                        <div class="thumbnail recent-properties-box">
                            <img src="../minimaladmin/<?php echo $row['photo']; ?>" alt="properties-7" class="img-responsive">
                            <!-- Detail -->
                            <div class="caption detail">
                                <!-- Header -->
                                <header class="clearfix">
                                    <div class="pull-left">
                                        <h1 class="title">
                                            <a href=""><?php echo $row['propertytitle']; ?></a>
                                        </h1>
                                    </div>
                                    <!-- Price -->
                                    <div class="price">
                                        RS <?php echo $row['maxprice']; ?>
                                    </div>
                                </header>
                                <!-- Location -->
                                <h3 class="location">
                                    <a href="#">
                                        <i class="fa fa-map-marker"></i><?php echo $row['address']; ?>
                                    </a>
                                </h3>
                                <!-- Facilities List -->
                                <ul class="facilities-list clearfix">
                                    <li class="bordered-right">
                                        <i class="flaticon-square-layouting-with-black-square-in-east-area"></i>
                                        <span><?php echo $row['maxarea']; ?> sq ft</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-bed"></i>
                                        <span><?php echo $row['rooms']; ?> Bedroom</span>
                                    </li>
                                    
                                    <li>
                                        <i class="flaticon-holidays"></i>
                                        <span><?php echo $row['bathrooms']; ?> Bathroom</span>
                                    </li>
                                    
                                    <li>
                                        <i class="flaticon-building"></i>
                                        <span> <?php echo $row['balconey']; ?> Balcony</span>
                                    </li>
									<li>
                                        <i class="flaticon-monitor"></i>
                                        <span><?php echo $row['furnished']; ?> Furnished</span>
                                    </li>
                                </ul>
                                <!-- Footer -->
                                <div class="footer">
                                    <a href="#">
                                        <i class="fa fa-user"></i> <?php echo $row['name']; ?>
                                    </a>
                                    <span>
                                        <i class="fa fa-calendar-o"></i> 1 day ago
                                    </span>
                                </div>
                            </div>
                            <!-- Tag -->
                            <span class="tag-f">
                                <a href="">RS <?php echo $row['maxprice']; ?></a>
                            </span>
                            <span class="tag-s">
                                <a href=""><?php echo $row['propertystatus']; ?></a>
                            </span>
                        </div>
                    </div>
                    
                    <?php
					}
					}
					else
					{
						$query="select * from propertydetail,propertystatus where propertydetail.propertystatus_id=propertystatus.propertystatus_id";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
					?> 
					<div class="col-lg-6 col-md-6 col-sm-6 wow fadeInUp delay-03s" >
                        <div class="thumbnail recent-properties-box">
                            <img src="../minimaladmin/<?php echo $row['photo']; ?>" alt="properties-7" class="img-responsive">
                            <!-- Detail -->
                            <div class="caption detail">
                                <!-- Header -->
                                <header class="clearfix">
                                    <div class="pull-left">
                                        <h1 class="title">
                                            <a href=""><?php echo $row['propertytitle']; ?></a>
                                        </h1>
                                    </div>
                                    <!-- Price -->
                                    <div class="price">
                                        RS <?php echo $row['maxprice']; ?>
                                    </div>
                                </header>
                                <!-- Location -->
                                <h3 class="location">
                                    <a href="#">
                                        <i class="fa fa-map-marker"></i><?php echo $row['address']; ?>
                                    </a>
                                </h3>
                                <!-- Facilities List -->
                                <ul class="facilities-list clearfix">
                                    <li class="bordered-right">
                                        <i class="flaticon-square-layouting-with-black-square-in-east-area"></i>
                                        <span><?php echo $row['maxarea']; ?> sq ft</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-bed"></i>
                                        <span><?php echo $row['rooms']; ?> Bedroom</span>
                                    </li>
                                    
                                    <li>
                                        <i class="flaticon-holidays"></i>
                                        <span><?php echo $row['bathrooms']; ?> Bathroom</span>
                                    </li>
                                    
                                    <li>
                                        <i class="flaticon-building"></i>
                                        <span> <?php echo $row['balconey']; ?> Balcony</span>
                                    </li>
									<li>
                                        <i class="flaticon-monitor"></i>
                                        <span> <?php echo $row['furnished']; ?> Furnished</span>
                                    </li>
                                </ul>
                                <!-- Footer -->
                                <div class="footer">
                                    <a href="#">
                                        <i class="fa fa-user"></i> <?php echo $row['name']; ?>
                                    </a>
                                    <span>
                                        <i class="fa fa-calendar-o"></i> 1 day ago
                                    </span>
                                </div>
                            </div>
                            <!-- Tag -->
                            <span class="tag-f">
                                <a href="#">RS <?php echo $row['maxprice']; ?></a>
                            </span>
                            <span class="tag-s">
                                <a href="#"><?php echo $row['propertystatus']; ?></a>
                            </span>
                        </div>
                    </div>
                    
					<?php
						}
					}
					?>
                </div>

                <!-- Page navigation start -->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li>
                            <a href="#" aria-label="Previous">
                                <span aria-hidden="true">Previous</span>
                            </a>
                        </li>
                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li>
                            <a href="#" aria-label="Next">
                                <span aria-hidden="true">Next</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- Page navigation end -->
            </div>
            <div class="col-lg-4 col-md-4 col-xs-12 col-md-pull-8">
                <!-- Search contents sidebar start -->
			<?php
				include("searchfilter.php");
			?>
		   </div>
        </div>
    </div>
</div>
<!-- Properties section body end -->

<!-- Partners block start -->
<div class="partners-block">
    <div class="container">

        <div class="container">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/audiojungle.png" alt="audiojungle">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/themeforest.png" alt="themeforest">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/tuts.png" alt="tuts">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/graphicriver.png" alt="graphicriver">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/codecanyon.png" alt="codecanyon">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Partners block end -->
<?php
include("include/footer.php");
?>
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-grid-leftside.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:24 GMT -->
</html>