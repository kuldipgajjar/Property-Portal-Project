<?php
include("include/header.php");
if(isset($_SESSION['id']))
{
	$id12=$_SESSION['id'];
}
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:26 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>
	<script type="text/javascript" src="js/jquery-1.12.4.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>
<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>Properties Detail</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Properties Detail</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Sub Banner end -->
<!-- Properties details page start -->
			<?php
				if(isset($_GET['detail_id']))
				{
					$id=$_GET['detail_id'];				
					
					$query="select * from propertydetail,p_subcategory,signup,area where propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.signup_id=signup.signup_id AND propertydetail.area_id=area.area_id AND propertydetail_id='$id'";
					$result=mysqli_query($con,$query);
					
				while($row=mysqli_fetch_array($result))
				{
				  $check=explode(',',$row['features']);
				  $count1=count($check);
			?>
<div class="properties-details-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="heading-icon-listings">
                    <a href="#" class="back-to-listings">
                        <i class="fa fa-chevron-left" style="padding:15px 2px;"></i>
                    </a>
                    <a href="#" class="back-to-listings pull-right">
                        <i class="fa fa-chevron-right " style="padding:15px 2px;"></i>
                    </a>
                </div>
            </div>
			
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="properties-details-section">
                    <!-- Header -->
                    <div class="heading-properties clearfix">
                        <div class="pull-left">
                            <h3><?php echo $row['propertytitle']; ?> ( <?php echo $row['subcategory']; ?> ) </h3> 
                            <p>
                                <?php echo $row['floorno']; ?> <?php echo $row['complexname']; ?> <?php echo $row['areaname']; ?>
                            </p>
                        </div>
                        <div class="pull-right">
                            <h3>RS <?php echo $row['maxprice']; ?></h3>
							
                        </div>
                    </div>
                    <!-- Properties detail slider start -->
                    <div class="properties-detail-slider simple-slider mrg-btm-40 ">
                        <div id="carousel-custom" class="carousel slide" data-ride="carousel">
                            <div class="carousel-outer">
                                <!-- Wrapper for slides -->
								<?php
								$img=explode(',',$row['photo']);
								$number_of_photos = count($img);
								?>
                                <div class="carousel-inner">
								<?php   
								$flag = 0;
								for ($i1 = 0 ; $i1< $number_of_photos ; $i1++) 
								{
									if($flag==0)
									{
										$flag=1;
									?>									
                                    <div class="item active">
                                        <img src="../minimaladmin/<?php echo  $img[$i1];  ?>" style="height:400px;" class="thumb-preview" alt="Chevrolet Impala">
                                    </div>									
								<?php
									}
									else
									{
									?>
									<div class="item">
                                        <img src="../minimaladmin/<?php echo  $img[$i1];  ?>" style="height:400px;" class="thumb-preview" alt="Chevrolet Impala">
                                    </div>
									<?php
									}
								}
								?>
                                  </div>
                                <!-- Controls -->
                                <a class="left carousel-control" href="#carousel-custom" role="button" data-slide="prev">
                                    <span class="slider-mover-left no-bg" aria-hidden="true">
                                        <img src="img/chevron-left.png" alt="chevron-left" style="padding:15px 2px;">
                                    </span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="right carousel-control" href="#carousel-custom" role="button" data-slide="next">
                                    <span class="slider-mover-right no-bg" aria-hidden="true">
                                        <img src="img/chevron-right.png" alt="chevron-right" style="padding:15px 2px;">
                                    </span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                            <!-- Indicators -->
                            <ol class="carousel-indicators thumbs visible-lg visible-md">
							
							<?php
								$img=explode(',',$row['photo']);
								$number_of_photos = count($img);
								?>
                              <?php   
								for ($i1=0 ; $i1< $number_of_photos ; $i1++) 
								{
									?>
									  <li data-target="#carousel-custom" data-slide-to="<?php echo $i1;?>" class=""><img src="../minimaladmin/<?php echo  $img[$i1];  ?>" alt="Chevrolet Impala"></li>
                               
									
                              <?php
								
								}
								?> 
							
                               </ol>
                        </div>
                    </div>
                    <!-- Properties detail slider end -->

                    <!-- Specifications start -->
                    <div class="sidebar specifications mrg-btm-30 clearfix hidden-lg hidden-md">
                        <div class="section-heading">
                            <div class="media">
                                <div class="media-left">
                                    <i class="flaticon-apartment"></i>
                                </div>
                                <div class="media-body">
                                    <h4>123</h4>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Reviews Box -->
                        <div class="reviews-box clearfix">
                            <ul class="reviews-star-list">
                                <li>
                                    <i class="fa fa-star"></i>
                                </li>
                                <li>
                                    <i class="fa fa-star"></i>
                                </li>
                                <li>
                                    <i class="fa fa-star"></i>
                                </li>
                                <li>
                                    <i class="fa fa-star"></i>
                                </li>
                                <li>
                                    <i class="fa fa-star-o"></i>
                                </li>
                            </ul>
                            <a href="#" class="add-review">
                                <i class="fa fa-plus-circle"></i>Add Review
                            </a>
                        </div>
                        <p>Voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui voluptatem sequi nesciunt.<br><br>
                            Neque porro quisqua. Sed ut perspiciatis unde omnis ste natus error sit voluptatem.</p>

                        <a href="addtocart.php" class="wishlist-btn">
                            <span class="wishlist-btn-l">
                                <i class="fa fa-plus"></i>
                            </span>
                            <span class="wishlist-btn-r">Add to favorite list</span>
                            <div class="clear"></div>
                        </a>
                        <a href="#" class="book-btn">
                            <span class="book-btn-l"><i class="fa fa-check"></i></span>
                            <span class="book-btn-r">Add to favorite list</span>
                            <div class="clear"></div>
                        </a>
                    </div>
                    <!-- Specifications end -->

                    <!-- Properties description start -->
                    <div class="properties-description mrg-btm-40 ">
                        <h3 class="heading">
                            Description                        
                        </h3>
						
                        <p><?php echo $row['description']; ?></p>
                    </div>
                    <!-- Properties description end -->

                    <!-- Properties condition start -->
                    <div class="properties-condition mrg-btm-40 ">
                        <h3 class="heading">
                            Property Details
                        </h3>
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <ul class="condition">
                                    <li>
                                        <?php echo $row['rooms'];?> Bedroom
                                    </li>
                                    <li>
                                         <?php echo $row['bathrooms']; ?> Bathroom
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <ul class="condition">
                                    <li>
                                        <?php echo $row['maxarea']; ?> max sq ft
                                    </li>
                                    <li>
                                        <?php echo $row['balconey'];?> Balcony
                                    </li>
                                </ul>
                            </div>
							<div class="col-md-4 col-sm-4 col-xs-12">
                                <ul class="condition">
                                    <li>
                                        <?php echo $row['minarea']; ?> min sq ft
                                    </li>
                                    
                                </ul>
                            </div>
							<div class="col-md-4 col-sm-4 col-xs-12">
                                <ul class="condition">
                                    <li>
                                        <?php echo $row['floor']; ?> Floor
                                    </li>
                                    
                                </ul>
                            </div>
							<div class="col-md-4 col-sm-4 col-xs-12">
                                <ul class="condition">
                                    <li>
                                       Status <?php echo $row['cons_status']; ?>
                                    </li>
                                    
                                </ul>
                            </div>
							                            
                        </div>
                    </div>
                    <!-- Properties condition end -->
                    <!-- Properties amenities start -->
                    <div class="properties-amenities mrg-btm-40 ">
                        <h3 class="heading">
                           Extra Features
                        </h3>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <ul class="amenities">
                                    
									<?php
										for($i=0;$i<$count1;$i++)
										{
									?>
									<li>
                                        <li><?php echo $check[$i]; ?></li>
									</li>
									<?php
										}
									?>                                    
                                </ul>
                            </div>                                                      
                        </div>
                    </div>
					<div class="heading">
                        <a href="#">
                          <a href="guest.php?eid=<?php echo $row['signup_id']; ?>&&pid=<?php echo $row['propertydetail_id']; ?>"> <button class="search-button" style="padding:8px 8px;background:red;width:130px;">Contact <?php echo $row['user_type']; ?></button></a>
						</a> 
						 						
                    </div>
                    <!-- Properties amenities end -->
                    <!-- Location start -->
                    <div class="sectionc location mrg-btm-40">
                        <div class="map">
                            <h3 class="heading">Location</h3>
						<iframe
							width="700"
							height="700"
							frameborder="0" style="border:0"
							src="https://www.google.com/maps/embed/v1/place?

							key=AIzaSyD3uMiVCwSnfZ4zO3uwVmxtqIkuqGnQ6zA
							&q= <?php echo $row['complexname']?>,<?php echo $row['areaname']?>,ahmedabad,india?>" allowfullscreen>
						</iframe>
                        </div>
                    </div>
                    <!-- Location end -->
                </div>                
            </div>
						
            <div class="col-lg-4 col-md-4 col-xs-12">
                <div class="sidebar right">
                    <!-- Specifications start -->
                    <div class="sidebar sidebar-widget specifications clearfix hidden-xs hidden-sm">
                        <div class="section-heading">
                            <div class="media">
                                <div class="media-left">
                                    <i class="flaticon-apartment"></i>
                                </div>
                                <div class="media-body">
                                    <h4><?php echo $row['propertytitle']; ?></h4>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Reviews Box -->
                        
                        <p><?php echo $row['description']; ?></p>

                        
                        <a class="book-btn">
                            <span class="book-btn-l"><i class="fa fa-check"></i></span>
                            <span class="book-btn-r" value="<?php echo $row['propertydetail_id']; ?>" id="bookmark">Add to favorite list</span>
                            <div class="clear"></div>
							<div style="color:blue;font-size:18px;" id="response"></div>
                        </a>
                    </div>
                    <!-- Specifications end -->

                    <!-- Print section start -->
                    		
					<script>
						$(document).ready(function(){
								$("#bookmark").click(function(){
									 var id =  $("#bookmark").attr('value');
									 var login_id = <?php echo $_SESSION['id']; ?>
									//alert(id);
									//alert(login_id);
									 $.ajax({
									type: "POST",
									url: "bookmark.php",
									
									data: { id: id , eid:login_id }
									}).done(function( msg ) {
									 //$("#response").html("Data Saved Successfully..");
									 $("#response").html(msg);
									//alert(msg);
									});
								});
							});
						
					</script>
                    <!-- print-section end -->

                    <!-- Agent widget start -->
                    
                    <div class="clearfix"></div>

                    <div class="clearfix"></div>
                    <!-- Helping center start -->
                    <div class="sidebar sidebar-widget helping-center">
                        <h3 class="title">Helping Center</h3>
                        <p></p>
                        <ul class="contact-link">
                            <li>
                                <i class="fa fa-map-marker"></i>
                                
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>
                                <a href="tel:+55-417-634-7071">
                                    
                                </a>
                            </li>
                            <li>
                                <i class="fa fa-envelope-o"></i>
                                <a href="mailto:info@themevessel.com">
                                    info@homy.com
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Helping center end -->

                    <!-- Social media box start -->
                    <div class="blog-share social-media-box sidebar-widget sidebar">
                        <h3 class="title">Social Media</h3>
                        <ul class="social-list">
                            <li>
                                <a href="http://facebook.com/mabuc" class="facebook-bg">
                                    <i class="fa fa-facebook" style="padding:15px 2px;"></i>
                                </a>
                            </li>
                            <li>
                                <a href="http://twitter.com/mabuc" class="twitter-bg">
                                    <i class="fa fa-twitter" style="padding:15px 2px;"></i>
                                </a>
                            </li>
                            <li>
                                <a href="http://google.com/" class="google-bg">
                                    <i class="fa fa-google" style="padding:15px 2px;"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="linkedin-bg">
                                    <i class="fa fa-linkedin" style="padding:15px 2px;"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="pinterest-bg">
                                    <i class="fa fa-pinterest" style="padding:15px 2px;"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Social media box end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Properties details page end -->
<?php
	}
}			
include("include/footer.php");
?>
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0N5pbJN10Y1oYFRd0MJ_v2g8W2QT74JE"></script>
<script>
    function LoadMap(propertes) {
        var defaultLat = 40.7110411;
        var defaultLng = -74.0110326;
        var mapOptions = {
            center: new google.maps.LatLng(defaultLat, defaultLng),
            zoom: 15,
            scrollwheel: false,
            styles: [
                {
                    featureType: "administrative",
                    elementType: "labels",
                    stylers: [
                        {visibility: "off"}
                    ]
                },
                {
                    featureType: "water",
                    elementType: "labels",
                    stylers: [
                        {visibility: "off"}
                    ]
                },
                {
                    featureType: 'poi.business',
                    stylers: [{visibility: 'off'}]
                },
                {
                    featureType: 'transit',
                    elementType: 'labels.icon',
                    stylers: [{visibility: 'off'}]
                },
            ]
        };
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        var infoWindow = new google.maps.InfoWindow();
        var myLatlng = new google.maps.LatLng(40.7110411, -74.0110326);

        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map
        });
        (function (marker) {
            google.maps.event.addListener(marker, "click", function (e) {
                infoWindow.setContent("" +
                        "<div class='map-properties contact-map-content'>" +
                        "<div class='map-content'>" +
                        "<p class='address'>20-21 Kathal St. Tampa City, FL</p>" +
                        "<ul class='map-properties-list'> " +
                        "<li><i class='fa fa-phone'></i>  +0477 8556 552</li> " +
                        "<li><i class='fa fa-envelope'></i>  info@themevessel.com</li> " +
                        "<li><a href='index.html'><i class='fa fa-globe'></i>  http://www.example.com</li></a> " +
                        "</ul>" +
                        "</div>" +
                        "</div>");
                infoWindow.open(map, marker);
            });
        })(marker);
    }
    LoadMap();
</script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/properties-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:37 GMT -->
</html>