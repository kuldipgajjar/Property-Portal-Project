 <?php
 $con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
  ?>
<div class="col-md-4" id="demo1">
    <div class="form-group">
<?php
if(isset($_GET['data1']))
 {
	$id=$_GET['data1'];
	
	$query="select * from  p_subcategory where category_id='$id'";
	$result=mysqli_query($con,$query);
?>
	<label>BHK</label>
	<select class="btn-group bootstrap-select search-fields" name="subcategory">
        <option hidden>Select Property BHK</option>
         <?php
			while($row5=mysqli_fetch_array($result))
			{
		?>
		<option value="<?php echo $row5['subcat_id']; ?>"><?php echo $row5['subcategory']; ?></option>
		<?php
		}
		?>
    </select>
	</div>
</div>
<?php
 }
?>
								