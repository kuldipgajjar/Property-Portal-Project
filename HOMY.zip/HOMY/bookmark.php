<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());

		$eid1=$_POST['eid'];
		$id1=$_POST['id'];	
	
	$query1="select * from bookmark where user_id='$eid1' AND property_id='$id1'";
	$result1=mysqli_query($con,$query1);
	$count=mysqli_num_rows($result1);
	if($count==1)
	{
		echo "already exist in bookmark";
	}
	else
	{
		
		
		$query="insert into bookmark values ('','$eid1','$id1')";
		mysqli_query($con,$query);
		echo "Data Saved Succesfully....";
	}
		
?>