<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
if(isset($_POST['submit']))
{
	$fullname=$_POST['fullname'];
	$email=$_POST['email'];
	$subject=$_POST['subject'];
	$phone=$_POST['phone'];
	$message=mysqli_real_escape_string($con,$_POST['message']);
		
	$query="insert into contact values('','$fullname','$email','$subject','$phone','$message')";
	mysqli_query($con,$query);
	
	
	$msg="Message Send Succesfully...";
	
}
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:11 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>

<!-- Option Panel -->

<!-- /Option Panel -->

<!-- Top header start -->
<?php
include("include/header.php");
?>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>Contact Us</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index-2.html">Home</a></li>
                    <li class="active">Contact Us</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Contact body start -->
<div class="contact-body">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Contact with us</h1>
            <div class="border">
                <div class="border-inner"></div>
            </div>
             
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                <!-- Contact form start -->
                <div class="contact-form">
                    <form id="contact_form" action="" method="post" enctype="multipart/form-data" name="myForm" onsubmit="return(validate());">
                        <div class="row">
						<span style="color:red;font-size:12px;" id="name"></span>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">									
                                <div class="form-group fullname">								
                                    <input type="text" name="fullname" class="input-text"  placeholder="Full Name">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group enter-email">
                                    <input type="text" name="email" class="input-text"  placeholder="Enter email">
                                <span style="color:red;" id="email">
								</div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group subject">
                                    <input type="text" name="subject" class="input-text"  placeholder="Subject">
                                <span style="color:red;" id="subject">
								</div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group number">
                                    <input type="text" name="phone" class="input-text"  placeholder="Phone Number">
                                <span style="color:red;" id="mobile"></span>
								</div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
                                <div class="form-group message">
                                    <textarea class="input-text" name="message"  placeholder="Write message"></textarea>
                                <span style="color:red;" id="message"></span>
								</div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group send-btn">
                                    <button type="submit" name="submit" class="button-md button-theme">Send Message</button>
                                </div>
                            </div>
                        </div>
                    </form>   
						<?php
						if(isset($msg))
						{
						?>
							<center ><h1 style="font-size: 18px;color: red;"><?php echo $msg; ?></h1></center>
							<?php
						}
						?>
                </div>
                <!-- Contact form end -->
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <!-- Contact details start -->
                <div class="contact-details">
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="media-body">
                            <h4>Office Address</h4>
                            <p>Pending...</p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="media-body">
                            <h4>Phone Number</h4>
                            <p>
                                <a href="tel:0477-0477-8556-552">Mobile 1: 9033879398</a>
                            </p>
                            <p>
                                <a href="tel:8160438564">Mobile 2: 8160438564</a>
                            </p>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="media-body">
                            <h4>Email Address</h4>
                            <p>
                                <a href="mailto:info@homy.com">info@homy.com</a>
                            </p>
                            <p>
                                <a href="www.example.html" target="_blank">www.example.com</a>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- Contact details end -->
            </div>
        </div>
    </div>
</div>
<!-- Contact body end -->

<!-- Google map start -->

<!-- Google map end -->

<!-- Sub footer start -->
<?php
include("include/footer.php");
?>
<!-- Sub footer end -->
<script type="text/javascript">
function validate()
      {
		  var name = document.myForm.fullname.value;
		  var email = document.myForm.email.value;
		  var subject = document.myForm.subject.value;		  
		  var mobile = document.myForm.phone.value;
		  var message = document.myForm.message.value;
		   	 
		 
		 if(name == "")
		 {
		 document.getElementById("name").innerHTML="Please Fill Name Filed.";
		 document.myForm.fullname.focus() ;
            return false;
         }
		 else{
			 document.getElementById("name").innerHTML="";
		 }
		 
		 if( email == "" )
         {
            document.getElementById("email").innerHTML="Please Fill the username field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.length <= 5) || (email.length > 25) )
		 {
			document.getElementById("email").innerHTML="user length must be between 5 and 25";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email").innerHTML="";
		 }
		 if( subject == "" )
         {
            document.getElementById("subject").innerHTML="Please Fill the subject field";
            document.myForm.subject.focus() ;
            return false;
         }
		 else{
			document.getElementById("subject").innerHTML=""; 
		 }
		 if(!isNaN(subject))
		 {
			document.getElementById("subject").innerHTML="Only character allowed";
            document.myForm.subject.focus() ;
            return false;
		 }
		 
		 if( mobile == "")
		 {
			document.getElementById("mobile").innerHTML="Please Fill the Mobile field";
            document.myForm.phone.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(isNaN(mobile))
		 {
			document.getElementById("mobile").innerHTML="User Must Enter Digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if(mobile.length !=10)
		 {
			document.getElementById("mobile").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile").innerHTML=""; 
		 }
		 if( message == "" )
         {
            document.getElementById("message").innerHTML="Please Fill the message field";
            document.myForm.message.focus() ;
            return false;
         }
		 else{
			document.getElementById("message").innerHTML=""; 
		 }
		 if((message.length <= 25) || (message.length > 100) )
		 {
			document.getElementById("message").innerHTML="message length must be between 25 and 100";
            document.myForm.message.focus() ;
            return false;
		 }	
		else{
			document.getElementById("message").innerHTML=""; 
		 }
		
		 return( true );
	  }
</script>
	
	
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0N5pbJN10Y1oYFRd0MJ_v2g8W2QT74JE"></script>
<script>
    function LoadMap(propertes) {
        var defaultLat = 40.7110411;
        var defaultLng = -74.0110326;
        var mapOptions = {
            center: new google.maps.LatLng(defaultLat, defaultLng),
            zoom: 15,
            scrollwheel: false,
            styles: [
                {
                    featureType: "administrative",
                    elementType: "labels",
                    stylers: [
                        {visibility: "off"}
                    ]
                },
                {
                    featureType: "water",
                    elementType: "labels",
                    stylers: [
                        {visibility: "off"}
                    ]
                },
                {
                    featureType: 'poi.business',
                    stylers: [{visibility: 'off'}]
                },
                {
                    featureType: 'transit',
                    elementType: 'labels.icon',
                    stylers: [{visibility: 'off'}]
                },
            ]
        };
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        var infoWindow = new google.maps.InfoWindow();
        var myLatlng = new google.maps.LatLng(40.7110411, -74.0110326);

        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map
        });
        (function (marker) {
            google.maps.event.addListener(marker, "click", function (e) {
                infoWindow.setContent("" +
                        "<div class='map-properties contact-map-content'>" +
                        "<div class='map-content'>" +
                        "<p class='address'>20-21 Kathal St. Tampa City, FL</p>" +
                        "<ul class='map-properties-list'> " +
                        "<li><i class='fa fa-phone'></i>  +0477 8556 552</li> " +
                        "<li><i class='fa fa-envelope'></i>  info@themevessel.com</li> " +
                        "<li><a href='index.html'><i class='fa fa-globe'></i>  http://www.example.com</li></a> " +
                        "</ul>" +
                        "</div>" +
                        "</div>");
                infoWindow.open(map, marker);
            });
        })(marker);
    }
    LoadMap();
</script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:12 GMT -->
</html>