<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());

include("include/header.php");
if(isset($_GET['eid']))
{
	$id=$_GET['eid'];
	$query="select * from signup where signup_id='$id'";
	$result=mysqli_query($con,$query);
	$row=mysqli_fetch_array($result);
}
if(isset($_GET['pid']))
{
	$id=$_GET['pid'];
	$query1="select * from propertydetail where propertydetail_id='$id'";
	$result1=mysqli_query($con,$query1);
	$row1=mysqli_fetch_array($result1);
}	
if(isset($_POST['submit']))
	{
		$name1=$_POST['name1'];
		$name2=$_POST['name2'];
		$name=$_POST['name'];
		$email=$_POST['email'];
		$mobile=$_POST['mobile'];
		
		$query="insert into guestdetail set signupid='$name1',propertyid='$name2',name2='$name',email1='$email',mobile1='$mobile'";
		mysqli_query($con,$query);
		?>
			<script type="text/javascript">
				window.location="guest.php?uid=<?php echo $name1 ?>";
			</script>
		<?php
			
}

?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/my-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:38 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>

<!-- Option Panel -->

<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>My Profile</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">My Profile</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- My profile start -->
<div class="my-profile" >
    <div class="container">
        <div class="row">
		<div class="col-lg-3 col-md-3 col-sm-4">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-5">
                <!-- My address start-->
                <div class="my-address">
					<?php
					if(isset($_GET['eid']) && isset($_GET['pid']))
					{
					?>
                    <h1>Detail</h1>
					
						<form action="" method="post" name="myForm" onsubmit="return(validate());">
						<div class="form-group">
						    <input type="hidden" class="input-text" name="name1"  value="<?php echo $row['signup_id']; ?>"  style="font-size:17px;">
                        </div>
						<div class="form-group">
						    <input type="hidden" class="input-text" name="name2"  value="<?php echo $row1['propertydetail_id']; ?>"  style="font-size:17px;">
                        </div>
                        <div class="form-group">
						  <label>Your Name</label>
                            <input type="text" class="input-text" name="name"   style="font-size:17px;">
                        <span style="color:red;" id="name1"></span>
						</div>
						<div class="form-group">
                            <label>Email</label>
                            <input type="text" class="input-text" name="email"   style="font-size:17px;">
                        <span style="color:red;" id="email1"></span>
						</div>
										
						<div class="form-group">
                            <label>Mobile</label>
                            <input type="text" class="input-text" name="mobile"  style="font-size:17px;">
                        <span style="color:red;" id="mobile1"></span>
						</div>						
                         <button type="submit" name="submit" value="submit" class="btn button-md button-theme">Submit</button> 
		               </form>
					   <?php
					}
					else if(isset($_GET['uid']))
					{
						$name1 = $_GET['uid'];
						
						$result_1 =mysqli_query($con,"select * from signup where signup_id = '$name1'");
						$row_1 = mysqli_fetch_array($result_1);
						?>
						<div class="my-address">					
						<h1>Thank You</h1>
						<div>Name :<h3 style="color:blue;text-transform:uppercase;"><?php  echo $row_1['name']; ?></h3></div>
						<div>Mobile :<h3 style="color:red;"><?php echo $row_1['mobile']; ?></h3></div>
						</div>
						<?php
					}					   
					?>
		            </div>
                <!-- My address end -->
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
                <!-- Avatar start -->
               
                <!-- Avatar end -->
            </div>
        </div>
    </div>
</div>
<!-- My profile end -->

<!-- Tesmimoniam section start -->

<!-- Tesmimoniam section end -->
<?php
include("include/footer.php");
?>
<!-- Sub footer end -->
<script type="text/javascript">
function validate()
      {
		  var name = document.myForm.name.value;
		  var email = document.myForm.email.value;		 
		  var mobile = document.myForm.mobile.value;		  		 
		 
		 if(name == "")
		 {
		 document.getElementById("name1").innerHTML="Please Fill Name Filed.";
		 document.myForm.name.focus() ;
            return false;
         }
		 else{
			 document.getElementById("name1").innerHTML="";
		 }
		 
		 if( email == "" )
         {
            document.getElementById("email1").innerHTML="Please Fill the username field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email1").innerHTML=""; 
		 }
		 if((email.length <= 5) || (email.length > 25) )
		 {
			document.getElementById("email1").innerHTML="user length must be between 5 and 25";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email1").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email1").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email1").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email1").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email1").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email1").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email1").innerHTML="";
		 }
		
		 if( mobile == "")
		 {
			document.getElementById("mobile1").innerHTML="Please Fill the Mobile field";
            document.myForm.mobile.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("mobile1").innerHTML=""; 
		 }
		 if(isNaN(mobile))
		 {
			document.getElementById("mobile1").innerHTML="User Must Enter Digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile1").innerHTML=""; 
		 }
		 if(mobile.length !=10)
		 {
			document.getElementById("mobile1").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.mobile.focus() ;
            return false;
		 }
		 else{
			document.getElementById("mobile1").innerHTML=""; 
		 }
		 
		 return( true );
	  }
</script>
<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/my-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:56:40 GMT -->
</html>