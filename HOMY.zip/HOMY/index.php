
<!DOCTYPE html>
<html lang="zxx">
<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
?>
<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:53:16 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>

<!-- Option Panel -->

<!-- /Option Panel -->
<?php
include("include/header.php");
?>
<!-- Banner start -->
<div class="banner text-center">
		<?php
		$query="select * from slider";
		$result=mysqli_query($con,$query);
		?>   
   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
		
			<?php
			$i=0;
				while($row=mysqli_fetch_array($result))
				{
				?>
				<div class="item <?php if($i==0){  echo "active"; } ?>">
				 <img src="../minimaladmin/<?php echo $row['imagename']; ?>">
                <div class="container">
                    <div class="carousel-caption banner-slider-inner banner-top-align">
                        <div>
                            <h1 data-animation="animated fadeInDown delay-05s"><span><?php echo $row['message1']; ?></span> <?php echo $row['message2']; ?></h1>
                        </div>
                    </div>
                </div>
				</div>
        
				<?php
				$i++;
				}
				?>
        </div>
	        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="slider-mover-left" aria-hidden="true">
                <img src="img/chevron-left.png" alt="chevron-left">
            </span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="slider-mover-right" aria-hidden="true">
                <img src="img/chevron-right.png" alt="chevron-right">
            </span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <div class="search-area hidden-xs" style="margin-bottom: 29px;margin-right:-252px;">
        <div class="search-area-inner">
            <div class="search-contents show-search-area animated fadeInUp">
			<form action="propertieslistleftsidebar.php" method="" name="myForm" onsubmit="return(validate());">
                <div class="row">
							<?php
								$query="select * from area";
								$result1=mysqli_query($con,$query);
							?>	
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <select class="selectpicker search-fields" name="area" id="area1">
                                <option value="" hidden>Area</option>
                                <?php
									while($row1=mysqli_fetch_array($result1))
									{
								?>
									<option  value="<?php echo $row1['area_id'];?>"><?php echo $row1['areaname']; ?></option>
								<?php
									}
								?>   
                            </select>
							<span style="color:red;font-size:15px;" id="area2"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
					<?php
						$query="select * from propertystatus";
						$result2=mysqli_query($con,$query);
					?>
                        <div class="form-group">
                            <select class="selectpicker search-fields" name="propertystatus" id="propertystatus1">
                                <option value="" hidden>Property Status</option>
                             <?php
								while($row2=mysqli_fetch_array($result2))
								{
							?>
                                <option value="<?php echo $row2['propertystatus_id']; ?>"><?php echo $row2['propertystatus']; ?></option>
                            <?php
								}
							?>	   
                            </select>
							<span style="color:red;font-size:15px;" id="propertystatus2"></span>
                        </div>
                    </div>
					
                    <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
					<?php
						$query="select * from p_category";
						$result3=mysqli_query($con,$query);
					?>
                        <div class="form-group">
                            <select class="selectpicker search-fields" name="category" id="category1">
                                <option value="" hidden>Property Types</option>
                            <?php
								while($row3=mysqli_fetch_array($result3))
									{
							?>
								<option value="<?php echo $row3['category_id']; ?>"><?php echo $row3['categoryname']; ?></option>
							<?php
									}
							?>    
                            </select>
							<span style="color:red;font-size:15px;" id="category2"></span>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
					    <div class="form-group">
                            <select class="selectpicker search-fields" name="minprice" id="minprice1" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="" hidden>Min Price</option>
								<option value="5000">5 Thousand</option>
								<option value="500000">5 Lac</option>
								<option value="1000000">10 Lac</option>
								<option value="2000000">20 Lac</option>
								<option value="4000000">40 Lac</option>
								<option value="6000000">60 Lac</option>
								<option value="8000000">80 Lac</option>
								<option value="10000000">1 Cr</option>
								<option value="12000000">1.2 Cr</option>
								<option value="14000000">1.4 Cr</option>
								<option value="16000000">1.6 Cr</option>
								<option value="18000000">1.8 Cr</option>
								<option value="20000000">2.0 Cr</option>
                            </select>
							<span style="color:red;font-size:15px;" id="minprice2"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
					
                        <div class="form-group">
                            <select class="selectpicker search-fields" name="maxprice" id="maxprice1" data-live-search="true" data-live-search-placeholder="Search value" >
                                <option value="" hidden>Max Price</option>
								<option value="100000">1 Lac</option>
								<option value="500000">5 Lac</option>
								<option value="1000000">10 Lac</option>
								<option value="2000000">20 Lac</option>
								<option value="4000000">40 Lac</option>
								<option value="6000000">60 Lac</option>
								<option value="8000000">80 Lac</option>
								<option value="10000000">1 Cr</option>
								<option value="12000000">1.2 Cr</option>
								<option value="14000000">1.4 Cr</option>
								<option value="16000000">1.6 Cr</option>
								<option value="18000000">1.8 Cr</option>
								<option value="20000000">2.0 Cr</option>
                            </select>
							<span style="color:red;font-size:15px;" id="maxprice2"></span>
                        </div>
                    </div>
													              
                    <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                           <button class="search-button" name="submit" type="submit">Search</button></a>
                        </div>
                    </div>
                </div>
				</form>
            </div>
        </div>
    </div>
</div>
<!-- Banner end -->

<div class="recent-properties">
   
   <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Recent Added property</h1>
            <div class="border">
                <div class="border-inner"></div>
            </div>
        </div>
	    <div class="row" style="width:1300px;">		
		<?php
			$query="SELECT * FROM propertydetail,furnished,propertystatus,p_subcategory,signup where propertydetail.subcat_id=p_subcategory.subcat_id AND propertydetail.furnished_id=furnished.furnished_id AND propertydetail.propertystatus_id=propertystatus.propertystatus_id AND propertydetail.signup_id=signup.signup_id group by propertydetail_id ORDER BY propertydetail.propertydetail_id DESC limit 0,3";
			$result23=mysqli_query($con,$query);
			while($row23=mysqli_fetch_array($result23))
			{
		?>			
            <div class="col-lg-4 col-md-4 col-sm-6 wow fadeInUp delay-03s">
                <!-- Recent properties box start -->
                <div class="thumbnail recent-properties-box">
							<?php
								$img=explode(',',$row23['photo']);
								$number_of_photos = count($img);
								 
								$flag = 0;
								for ($i1=0; $i1<$number_of_photos; $i1++) 
								{
									if($flag==0)
									{
									$flag=1;
							?>
							<img src="../minimaladmin/<?php echo $img[$i1];?>" style="height:300px;" alt="properties-1" class="img-responsive">
							<?php
									}
								}
							?>
				   <!-- Detail -->
                    <div class="caption detail">
                        <!-- Header -->
                        <header>
                            <div class="pull-left">
                                <h1 class="title">
                                    <a href="#"><?php echo $row23['propertytitle']; ?></a> ( <?php echo $row23['subcategory']; ?> )
                                </h1>
                            </div>
                            <!-- Price -->
                            <div class="price">
                                 RS <?php echo $row23['maxprice']; ?>
                            </div>
                        </header>
                        <!-- Location -->
                        <h3 class="location">
                            <a href="#">
                                <i class="fa fa-map-marker"></i><?php echo $row23['floorno']?> <?php echo $row23['complexname']?>
                            </a>
                        </h3>
                        <!-- Facilities List -->
                        <ul class="facilities-list clearfix">
                            <li class="bordered-right">
                                <i class="flaticon-square-layouting-with-black-square-in-east-area"></i>
                                <span><?php echo $row23['maxarea']; ?>  sq ft</span>
                            </li>
                            <li>
                                <i class="flaticon-bed"></i>
                                <span><?php echo $row23['rooms']; ?> Bedroom</span>
                            </li>
                            <li>
                                <i class="flaticon-holidays"></i>
                                <span><?php echo $row23['bathrooms']; ?> Bathroom</span>
                            </li>
                           <li>
                                <i class="flaticon-building"></i>
                                <span> <?php echo $row23['balconey']; ?> Balcony</span>
                            </li>
                            <li>
                                <i class="flaticon-monitor"></i>
                                <span> <?php echo $row23['furnished']; ?> Furnished</span>
                            </li>
							<li>
                                <i class="fa fa-home"></i>
                                <span> <?php echo $row23['cons_status']; ?></span>
                            </li>
                        </ul>
                        <!-- Footer -->
                        <div class="footer">
                            <a href="#">
							  <a href="guest.php?eid=<?php echo $row23['signup_id']; ?>&&pid=<?php echo $row23['propertydetail_id']; ?>"> <button class="search-button" style="padding:8px 8px;background:red;width:130px;">Contact <?php echo $row23['user_type']; ?></button></a>
							</a>
							<a href="#">						
							 <a href="feedback.php?pid=<?php echo $row23['propertydetail_id']; ?>"> <button class="search-button" style="padding:8px 8px;background:red;width:130px;">Send Feedback</button></a>
							</a>
                                  <span>
                                    <i class="fa fa-calendar-o"></i> <?php echo $row23['date']; ?>
                                </span>
                        </div>
                    </div>
                    <!-- Tag -->
                    <span class="tag-f">
                            <a href="propertiesdetails.php?detail_id=<?php echo $row23['propertydetail_id'];?>">Featured</a>
                        </span>
                    <span class="tag-s">
                        <a href="#"><?php echo $row23['propertystatus']; ?></a>
                    </span>
                </div>
                <!-- Recent properties box end -->
            </div>
            <?php
			}
			?>    
		</div>
    </div>
</div>
<!-- Recent properties end -->

<!-- Section-1 start -->
<div class="section-1 looking-for">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>What are you looking for?</h1>
            <div class="border">
                <div class="border-inner"></div>
            </div>
        </div>

        <div class="row mgn-btm wow">
            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="content">
                    <i class="flaticon-apartment"></i>
                    <h4>Apartments</h4>
                   
                </div>
            </div>
            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="content">
                    <i class="flaticon-internet"></i>
                    <h4>Houses</h4>
                    
                </div>
            </div>
            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12 wow fadeInRight delay-04s">
                <div class="content">
                    <i class="flaticon-apartment"></i>
                    <h4>Flat</h4>
                    
                </div>
            </div>
            
        </div>
        
    </div>
</div>
<!-- Section-1 end -->
<!-- Section-2 start -->
<div class="section-2 content-area articles-tips">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Articles</h1>
            <div class="border">
                <div class="border-inner"></div>
            </div>
        </div>
        <div class="row wow">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="thumbnail articles-box">
                    <img src="img/blog/blog-2.jpg" alt="blog-2" class="img-responsive">
                    <!-- Detail -->
                    <div class="caption detail">
                        <!--  title -->
                        <h1 class="title "><a href="#">Bedroom Colors </a></h1>
                        <!-- paragraph -->
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 wow fadeInLeft delay-04s">
                <div class="thumbnail articles-box">
                    <img src="img/blog/blog-1.jpg" alt="blog-1" class="img-responsive">
                    <!-- Detail -->
                    <div class="caption detail">
                        <!--  title -->
                        <h1 class="title"><a href="#">Help You Finding New Flat</a></h1>
                        <!-- paragraph -->
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 wow fadeInRight delay-04s">
                <div class="thumbnail articles-box">
                    <img src="img/blog/blog-3.jpg" alt="blog-3" class="img-responsive">
                    <!-- Detail -->
                    <div class="caption detail">
                        <!--  title -->
                        <h1 class="title"><a href="#">Buying Apartment</a></h1>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 wow fadeInRight delay-04s">
                <div class="thumbnail articles-box">
                    <img src="img/blog/blog-4.jpg" alt="blog-4" class="img-responsive">
                    <!-- Detail -->
                    <div class="caption detail">
                        <!--  title -->
                        <h1 class="title"><a href="#">Finding New Home</a></h1>
                        <!-- paragraph -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Section-2 end -->

<!-- Counters strat -->
<div class="counters">
    <div class="counters-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 wow fadeInLeft delay-04s">
                    <div class="counter-box">
					<?php
						$query="select count(propertystatus_id) AS sell from propertydetail where propertystatus_id='2'";
						$result=mysqli_query($con,$query);
						$row3=mysqli_fetch_array($result);
					?>
                        <i class="flaticon-tag"></i>
                        <h1 class="counter"><?php echo $row3['sell']; ?></h1>
                        <p>Listings For Sale</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 wow fadeInLeft delay-04s">
                    <div class="counter-box">
					<?php
						$query="select count(propertystatus_id) AS rent from propertydetail where propertystatus_id='1'";
						$result=mysqli_query($con,$query);
						$row4=mysqli_fetch_array($result);
					?>
                        <i class="flaticon-symbol-1"></i>
                        <h1 class="counter"><?php echo $row4['rent']; ?></h1>
                        <p>Listings For Rent</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 wow fadeInRight delay-04s">
                    <div class="counter-box">
					<?php
						$query="select count(signup_id) AS user from signup";
						$result=mysqli_query($con,$query);
						$row5=mysqli_fetch_array($result);
					?>
                        <i class="flaticon-people"></i>
                        <h1 class="counter"><?php echo $row5['user']; ?></h1>
                        <p>User</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 wow fadeInRight delay-04s">
                    <div class="counter-box">
					<?php
						$query="SELECT count(propertydetail_id) AS property from propertydetail";
						$result=mysqli_query($con,$query);
						$row6=mysqli_fetch_array($result);
					?>
                        <i class="flaticon-people-1"></i>
                        <h1 class="counter"><?php echo $row6['property']; ?></h1>
                        <p>Total Property</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->

<!-- Partners block start -->
<div class="partners-block">
    <div class="container">
        <div class="container">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/audiojungle.png" alt="audiojungle">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/themeforest.png" alt="themeforest">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/tuts.png" alt="tuts">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/graphicriver.png" alt="graphicriver">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3">
                                <a href="#">
                                    <img src="img/brand/codecanyon.png" alt="codecanyon">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Partners block end -->
<?php
include("include/footer.php");
?>

<script type="text/javascript">
function validate()
      {
		 
		var e = document.getElementById("area1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		if(strUser==0 || strUser == "Area" )
		{
			document.getElementById("area2").innerHTML="Please Select area Filed.";
			return false;
			
		}else{
				document.getElementById("area2").innerHTML="";
			}
			
		var e = document.getElementById("propertystatus1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		if(strUser==0 || strUser == "Property Status" )
		{
			document.getElementById("propertystatus2").innerHTML="Please Select propertystatus Filed.";
			return false;
			
		}else{
				document.getElementById("propertystatus2").innerHTML="";
			}
			
		var e = document.getElementById("category1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		if(strUser==0 || strUser == "Property Types" )
		{
			document.getElementById("category2").innerHTML="Please Select category Filed.";
			return false;
			
		}else{
				document.getElementById("category2").innerHTML="";
			}
		var e = document.getElementById("minprice1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		if(strUser==0 || strUser == "Min Price" )
		{
			document.getElementById("minprice2").innerHTML="Please Select minprice Filed.";
			return false;
			
		}else{
				document.getElementById("minprice2").innerHTML="";
			}
		var e = document.getElementById("maxprice1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		if(strUser==0 || strUser == "Max Price" )
		{
			document.getElementById("maxprice2").innerHTML="Please Select maxprice Filed.";
			return false;
			
		}else{
				document.getElementById("maxprice2").innerHTML="";
			}
		  
		 return (true) ;
	  }
</script>

<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>

</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:55:18 GMT -->
</html>