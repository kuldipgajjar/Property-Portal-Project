<?php
$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:12 GMT -->
<head>
    <title>HOMY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-submenu.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" href="css/leaflet.css" type="text/css">
    <link rel="stylesheet" href="css/map.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" type="text/css" href="fonts/linearicons/style.css">
    <link rel="stylesheet" type="text/css"  href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css"  href="css/dropzone.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/default.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script type="text/javascript" src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <script type="text/javascript" src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>

<!-- Option Panel -->

<!-- /Option Panel -->

<!-- Top header start -->
<?php
include("include/header.php");
?>
<!-- Main header end -->

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <div class="top">
                    <h1>About Us</h1>
                </div>
                <ul class="breadcrumbs">
                    <li><a href="index-2.html">Home</a></li>
                    <li class="active">About Us</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- About city estate start -->
<div class="about-city-estate">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="car-detail-slider simple-slider">
                    <div id="carousel-custom" class="carousel slide" data-ride="carousel">
                        <div class="carousel-outer">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item">
                                    <img src="img/properties/properties-1.jpg" class="img-preview" alt="properties-1">
                                </div>
                                <div class="item">
                                    <img src="img/properties/properties-2.jpg" class="img-preview" alt="properties-2">
                                </div>
                                <div class="item">
                                    <img src="img/properties/properties-5.jpg" class="img-preview" alt="properties-3">
                                </div>
                                <div class="item active left">
                                    <img src="img/properties/properties-8.jpg" class="img-preview" alt="properties-8">
                                </div>
                                <div class="item next left">
                                    <img src="img/properties/properties-3.jpg" class="img-preview" alt="properties-5">
                                </div>
                            </div>
                            <!-- Controls -->
                            <a class="left carousel-control" href="#carousel-custom" role="button" data-slide="prev">
                                    <span class="slider-mover-left no-bg" aria-hidden="true">
                                        <img src="img/chevron-left.png" alt="chevron-left">
                                    </span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#carousel-custom" role="button" data-slide="next">
                                    <span class="slider-mover-right no-bg" aria-hidden="true">
                                        <img src="img/chevron-right.png" alt="chevron-right">
                                    </span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="about-text">
                    <h3>Introduction</h3>
                    <p style="color:#040406;font-size:16px;">
					This Website is designed to attend to all your needs – from buying , selling and renting properties in Ahmedabad. Here you found the better opportunity to invest your values of entire life. Homy help us to maintain the database of various property and agents information. If you looking to buy , sell , rent and invest in a property than here is the better place to think forward. We know it is a tiring to call individual property agent arrange appointment finding better time for appointment and they will assist you. For such complex process we provide a simple online form and a guide which require you basic information and we will assist in minimum time period.
					</p>
                                  
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About city estate end -->

<!-- About team meet start -->
<div class="about-team-meet">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Our Agents</h1>
            <div class="border">
                <div class="border-inner"></div>
            </div>
            
        </div>
		
        <div class="row">
		<?php
			$query="SELECT * FROM agent ORDER BY agent.agent_id ASC limit 0,3";
			$result=mysqli_query($con,$query);
			while($row=mysqli_fetch_array($result))
			{
			?>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 clearfix">
			
                <!-- About box start-->
                <div class="thumbnail about-box wow fadeInLeft delay-03s">
                    <img src="../minimaladmin/<?php echo $row['agent_photo']; ?>"style="height:300px;" alt="team-1" class="img-responsive">
                    <!-- Detail -->
                    <div class="caption detail">
                        <h3><a href="#"><?php echo $row['agentname']; ?></a></h3>
                        <!-- contact -->
                        <div class="contact">
                            <p>
                                <i class="fa fa-envelope-o"></i>
                                <a href="mailto:info@themevessel.com"><?php echo $row['agentemail']; ?></a>
                            </p>
                            <p>
                                <i class="fa fa-mobile"></i><a href="tel:+55417-634-7071"><?php echo $row['agentphone']; ?></a>
                            </p>
                        </div>
                        <!-- social List -->
                        <ul class="social-list clearfix">
                            <li>
                                <a href="http://facebook.com/mabuc" class="facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="http://twitter.com/mabuc" class="twitter">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="http://linkedin.com/" class="linkedin">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="http://google.com/" class="google">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
			
                <!-- About box end -->
            </div>
			<?php
			}
			?>
         </div>
		 
    </div>
		
</div>
<!-- About team meet end -->
<div class="clearfix"></div>

<!-- Testimonial secion start -->


<?php
include("include/footer.php");
?>
<!-- Sub footer end -->

<script type="text/javascript" src="js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-submenu.js"></script>
<script type="text/javascript" src="js/rangeslider.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="js/leaflet.js"></script>
<script type="text/javascript" src="js/leaflet-providers.js"></script>
<script type="text/javascript" src="js/leaflet.markercluster.js"></script>
<script type="text/javascript" src="js/dropzone.js"></script>
<script type="text/javascript" src="js/maps.js"></script>
<script type="text/javascript" src="js/app.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script type="text/javascript" src="js/ie10-viewport-bug-workaround.js"></script>
<script>
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
     ga('create', 'UA-89110077-3', 'auto');
     ga('send', 'pageview');
  </script>
</body>

<!-- Mirrored from real-house-dot-themeforest-171208.appspot.com/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jan 2018 10:57:12 GMT -->
</html>