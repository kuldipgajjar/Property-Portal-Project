
<div class="sub-footer">
    <div class="container">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="copy-right">
                &copy;  2018 <a href="http://themevessel.com/" target="_blank"></a> Best Property Buy & Sell.
            </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="social-list">
                <ul class="clearfix">
                    <li class="twitter">
                        <a href="http://twitter.com/mabuc" target="_blank">
                            <i class="fa fa-twitter"></i>
                        </a>
                    </li>
                    <li class="facebook">
                        <a href="http://facebook.com/mabuc" target="_blank">
                            <i class="fa fa-facebook"></i></a>
                    </li>
                    <li class="youtube">
                        <a href="http://youtube.com/" target="_blank">
                            <i class="fa fa-youtube"></i>
                        </a>
                    </li>
                    <li class="linkedin">
                        <a href="http://linkedin.com/" target="_blank">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </li>
                    <li class="pinterest">
                        <a href="http://pinterest.com/mabuc" target="_blank">
                            <i class="fa fa-pinterest"></i>
                        </a>
                    </li>
                    <li class="dribbble">
                        <a href="http://dribbble.com/mabuc" target="_blank">
                            <i class="fa fa-dribbble"></i>
                        </a>
                    </li>
                    <li class="gplus">
                        <a href="http://google.com/" target="_blank">
                            <i class="fa fa-google-plus"></i>
                        </a>
                    </li>
                    <li class="instagram">
                        <a href="http://instagram.com/envato" target="_blank">
                            <i class="fa fa-instagram"></i>
                        </a>
                    </li>
                    <li class="rss">
                        <a href="http://feedburner.com/" target="_blank">
                            <i class="fa fa-rss"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>