<?php
session_start();
?>
<header class="top-header hidden-xs" id="top">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <div class="list-inline">
                    <a href="tel:1-8X0-666-8X88"><i class="fa fa-phone"></i>Need Support? X-74-P-930</a>
                    <a href="tel:info@themevessel.com"><i class="fa fa-envelope"></i>info@homy.com</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <ul class="top-social-media pull-right">
                   
                    <li>
                        <a href="#"><i class="fa fa-envelope-o"></i></a>
                    </li>
                    <li>
                        <a href="http://facebook.com/mabuc"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                        <a href="http://twitter.com/mabuc"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="http://google.com/"><i class="fa fa-google-plus"></i></a>
                    </li>
					                   
                    <li style="font-size:16px;">
					<!--<span class="sign-in"><i class="fa fa-user"></i></span><a href="#"id="myBtn">Sign In</a><a href="#"id="myBtn">LogIn</a>-->
					
					<?php
					if(isset($_SESSION['id']))
					{
						 $id=$_SESSION['id'];
						 
						$con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
						$query="select * from signup where signup_id='$id'";
						$result=mysqli_query($con,$query);						
						$row=mysqli_fetch_array($result);					
						?>
						<li>
							<div class="dropdown">
								<i class="fa fa-user"></i>&nbsp <a href="#"  onclick="myFunction()" class="dropbtn" ><?php echo "Hello &nbsp".$row['name'];?></a>
									<div id="myDropdown" class="dropdown-content"style="padding-top:8px;width:297px;margin-left:-52px;">
										<div class="modal-content">
										<!-- My account box start -->
										<div class="my-account-box" >
											<div class="item" style="text-align:left;height: 335px;">
												<h3 class="title">
												Manage Account
												</h3>
											<p style="color:black;">
												<a href="myprofile.php" style="color:black;">
													<i class="flaticon-social"></i>My Profile
												</a>
											</p>
											<p>
												<a href="mybookmarks.php" style="color:black;">
													<i class="flaticon-shape"></i>Bookmarked Listings
												</a>
											</p>													  
											<p>
												<a href="myproperties.php" style="color:black;">
													<i class="flaticon-apartment"></i>My Properties
												</a>
											</p>													  
											<p>
												<a href="changepassword.php" style="color:black;">
													<i class="flaticon-security"></i>Change Password
												</a>
											</p>
											<p>
											  <a href="user_logout.php" class="search-button" style="padding:1px 8px;background:#d83764;color:white;font-size:21px;text-align:center;">Logout</a>   
											</p>
											
									</div>
									<!-- My account box end -->
									</div>
								</div>
							</div>
						</li>
						<?php
					}
					else
					{
						?>
						<a href="login.php" class="search-button" style="padding:1px 8px; background: #d83764;">Log in</a>&nbsp &nbsp
						<a href="signup.php" class="search-button" style="padding:1px 8px; background: #d83764;">Sign up</a>						
						<?php
					}					
					?>      
                   
					</li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!-- Top header end -->

<!-- Main header start -->
<header class="main-header">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navigation" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php" class="logo">
                    <img src="img/logos/logo.png" alt="logo">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse collapse" role="navigation" aria-expanded="true" id="app-navigation">
                <ul class="nav navbar-nav">
                    <li class="dropdown">
                        <li><a href="index.php">Home</a></li>
                    </li>
                    <li class="dropdown">
                        <li><a href="propertieslistleftsidebar.php">Property</a></li>
                    </li>
					
					<li class="dropdown">
                        <li><a href="sell.php">Sell</a></li>
                    </li>
					<li class="dropdown">
                        <li><a href="rent.php">Rent</a></li>
                    </li>
					<li class="dropdown">
                        <li><a href="about.php">About Us</a></li>
                    </li>
					<li class="dropdown">
                        <li><a href="contact.php">Contact</a></li>
                    </li>
				</ul>
					<ul class="nav navbar-nav navbar-right rightside-navbar">
						<?php
						if(isset($_SESSION['id']))
						{
						?>	<li>
								<a href="addproperty.php" class="button">Submit Property</a>
							</li>
						<?php
						}
						else
						{
						?>	<li>
								<a href="login.php" class="button">Submit Property</a>
							</li>
						<?php
						}
						?>
					</ul>				
        </nav>
    </div>
</header>

<script>
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

</script>


