<div class="col-lg-3 col-md-3 col-sm-4">
                <!-- My account box start -->
                <div class="my-account-box">
                    <div class="item">
                        <h3 class="title">
                            Manage Account
                        </h3>
                        <p>
                            <a href="myprofile.php" style="font-size:17px;">
                                <i class="flaticon-social"></i>My Profile
                            </a>
                        </p>
                        <p>
                            <a href="mybookmarks.php" style="font-size:17px;">
                                <i class="flaticon-shape"></i>Bookmarked Listings
                            </a>
                        </p> 
                        <p>
                            <a href="myproperties.php" style="font-size:17px;">
                                <i class="flaticon-apartment"></i>My Properties
                            </a>
                        </p>    
                   
                        <p>
                            <a href="changepassword.php" style="font-size:17px;">
                                <i class="flaticon-security"></i>Change Password
                            </a>
                        </p>
                        
                    </div>
                </div>
                <!-- My account box end -->
            </div>