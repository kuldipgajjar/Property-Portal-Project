<?php
session_start();

if(isset($_SESSION['id']))
{
	header("location:index12.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
			if(isset($_POST['submit']))
			{						
				$user=$_POST['username'];
				$pass=$_POST['pass'];
								
				$conn=mysqli_connect("localhost","root","","property") or die(mysqli_error());
				$query="select * from agent where agentemail='$user' and agent_password='$pass'";
				$result=mysqli_query($conn,$query) or die(mysqli_error());
				$row=mysqli_fetch_array($result);
				$count=mysqli_num_rows($result);
					if($count==1)
					{
						//$_SESSION['log']=$user;
						$_SESSION['id']=$row['agent_id'];
						header("location:index12.php");
					}
					/*if($user=='admin' && $pass =='admin')
					{
						header("location:index1.php");
					
					}*/
					else
					{
						$msg="invalid Username & Password";
					}
			}
?>
	<!-- General meta information -->
	<title>Login Form</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta name="robots" content="index, follow" />
	<meta charset="utf-8" />
	<!-- // General meta information -->
	<!-- Load Javascript -->
	<script type="text/javascript" src="js2/jquery.js"></script>.......
	<script type="text/javascript" src="js2/jquery.query-2.1.7.js"></script>
	<script type="text/javascript" src="js2/rainbows.js"></script>
	<!-- // Load Javascipt -->
	<!-- Load stylesheets -->
	<link type="text/css" rel="stylesheet" href="css2/style.css" media="screen" />
	<!-- // Load stylesheets -->
<script>
	$(document).ready(function(){
 
	$("#submit1").hover(
	function() {
	$(this).animate({"opacity": "0"}, "slow");
	},
	function() {
	$(this).animate({"opacity": "1"}, "slow");
	});
 	});
</script>
</head>
<body>
<div id="wrapper">
  <div id="wrappertop"></div>
	<div id="wrappermiddle">
		<h2>Agent Login</h2>
		  <div id="username_input">
			<div id="username_inputleft"></div>
			  <div id="username_inputmiddle">
				<form action="" method="post">
					<input type="text" name="username" id="url" value="Enter Username" onclick="this.value = ''">
					<img id="url_user" src="images/mailicon.png" alt="">
			  </div>
			<div id="username_inputright"></div>
			</div>
			<div id="password_input">
				<div id="password_inputleft">
				</div>
				  <div id="password_inputmiddle">
					<input type="password" name="pass" id="url" value="Password" onclick="this.value = ''">
					<img id="url_password" src="images/passicon.png" alt="">
				   </div>
				<div id="password_inputright"></div>
			</div>
			<div id="submit">
				<input type="image" name="submit" src="images/submit_hover.png" id="submit1" value="Sign In">
				<input type="image" src="images/submit.png" id="submit2" value="Sign In">
				</form>
			</div>
					<?php
						if(isset($msg))
						{
						?>
							<center><h1><?php echo $msg; ?></h1></center>
							<?php
						}
						?>
			<div id="links_left">
			<a href="#">Forgot your Password?</a>
			<a href="index.php">Admin Login</a>
			</div>
	</div>
<div id="wrapperbottom"></div>
</div>
</body>
</html>