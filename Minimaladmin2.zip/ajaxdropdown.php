 <?php
 $con=mysqli_connect("localhost","root","","property") or die(mysqli_error());
 if(isset($_GET['data1']))
 {
	$id=$_GET['data1'];
		 
	 $query="select * from  p_subcategory where category_id='$id'";
	 $result=mysqli_query($con,$query);
 ?>
	<select class="form-control" name="category">
		<option hidden>Select SubCategory</option>
		<?php
		  while($row3=mysqli_fetch_array($result))
		{
		?>
		<option value="<?php echo $row3['subcat_id'];?>"><?php echo $row3['subcategory']; ?></option>
		<?php
		}
		?>
	</select>
<?php
 }
 else if(isset($_GET['data2']))
 {
	 $id=$_GET['data2'];
	 
		$query="select * from area where cityid='$id'";
		$result8=mysqli_query($con,$query);
	?>	
        <select class="form-control" name="">
			<option hidden>Select Area</option>
			<?php
			while($row5=mysqli_fetch_array($result8))
			{
			?>
            <option value="<?php echo $row5['area_id']; ?>"> <?php echo $row5['areaname']; ?></option>
			<?php
			}
			?>
        </select>
<?php
}
?>