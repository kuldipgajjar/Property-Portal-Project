﻿
<!DOCTYPE html>
<?php
session_start();
$con=mysqli_connect('localhost','root','','property') or die(mysqli_error());
if(isset($_POST['submit']))
{
	$propertytitle=$_POST['propertytitle'];
	$propertystatus=$_POST['propertystatus'];
	$category=$_POST['category'];
	$subcategory=$_POST['subcategory'];
	$minprice=$_POST['minprice'];
	$maxprice=$_POST['maxprice'];
	$minarea=$_POST['minarea'];
	$maxarea=$_POST['maxarea'];
	$rooms=$_POST['rooms'];
	$bathrooms=$_POST['bathrooms'];
	$balconey=$_POST['balconey'];
	$furnished=$_POST['furnished'];
	$floor=$_POST['floor'];
	$cons_status=$_POST['cons_status'];
	$date=$_POST['date'];
	
	$count=count($_FILES['img']['name']);
		
		$file_array = array();
		for($i=0 ; $i<$count ; $i++)
		{			
			$name = $_FILES['img']['name'][$i];
			$src_path = $_FILES['img']['tmp_name'][$i];
			$dest_path = "images/propertyimg/".rand(0,100000000).$name ; 
			array_push($file_array , $dest_path);
			move_uploaded_file($src_path,$dest_path);		
		}
	$final_dest_path=implode(',',$file_array);
		
	$floorno=$_POST['floorno'];
	$complexname=$_POST['complexname'];
	$city=$_POST['city'];
	$area=$_POST['area'];
	$postalcode=$_POST['postalcode'];
	$description=mysqli_real_escape_string($con,$_POST['description']);
	$feature=$_POST['check'];
	$a=implode(',',$feature);	
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	
	$query="insert into propertydetail values('','$propertytitle','$propertystatus','$category','$subcategory','$minprice','$maxprice','$minarea','$maxarea','$rooms','$bathrooms','$balconey','$furnished','$floor','$cons_status','$date','$final_dest_path','$floorno','$complexname','$city','$area','$postalcode','$description','$a','admin','$email','$phone')";
	$result=mysqli_query($con,$query);
	
	header("location:viewproperty1.php");
}
if(isset($_POST['edit']))
{
	$id=$_GET['property_id'];
	
			$query_delete="select * from propertydetail where propertydetail_id='$id'";
			$result_delete=mysqli_query($con,$query_delete);
			$row_delete = mysqli_fetch_array($result_delete);
			$img1=explode(',', $row_delete['photo']);
			$number_of_photos_delete = count($img1);
											
			for ($i2=0; $i2<$number_of_photos_delete; $i2++) 
			{			
				unlink($img1[$i2]);
			}
	$propertytitle=$_POST['propertytitle'];
	$propertystatus=$_POST['propertystatus'];
	$category=$_POST['category'];
	$subcategory=$_POST['subcategory'];
	$minprice=$_POST['minprice'];
	$maxprice=$_POST['maxprice'];
	$minarea=$_POST['minarea'];
	$maxarea=$_POST['maxarea'];
	$rooms=$_POST['rooms'];
	$bathrooms=$_POST['bathrooms'];
	$balconey=$_POST['balconey'];
	$furnished=$_POST['furnished'];
	$floor=$_POST['floor'];
	$cons_status=$_POST['cons_status'];
	$date=$_POST['date'];
	
	 $count=count($_FILES['img']['name'])."count";
		
		$file_array = array();
		for($i=0 ; $i<$count ; $i++)
		{			
			$name = $_FILES['img']['name'][$i];
			$src_path = $_FILES['img']['tmp_name'][$i];
			$dest_path = "images/propertyimg/".rand(0,100000000).$name ; 
			array_push($file_array , $dest_path);
			move_uploaded_file($src_path,$dest_path);		
		}    
		$final_dest_path=implode(',',$file_array);
	
	$floorno=$_POST['floorno'];
	$complexname=$_POST['complexname'];
	$city=$_POST['city'];
	$area=$_POST['area'];
	$postalcode=$_POST['postalcode'];
	$description=mysqli_real_escape_string($con,$_POST['description']);
	$feature=$_POST['check'];
	$a=implode(',',$feature);	
	$email=$_POST['email'];
	$phone=$_POST['phone'];
		
	$query="update propertydetail set propertytitle='$propertytitle',propertystatus_id='$propertystatus',category_id='$category',subcat_id='$subcategory',minprice='$minprice',maxprice='$maxprice',minarea='$minarea',maxarea='$maxarea',rooms='$rooms',bathrooms='$bathrooms',balconey='$balconey',furnished_id='$furnished',floor='$floor',cons_status='$cons_status',date='$date',photo='$final_dest_path',floorno='$floorno',complexname='$complexname',cityid='$city',area_id='$area',postalcode='$postalcode',description='$description',features='$a',email='$email',phone='$phone' where propertydetail_id='$id'";
			
    mysqli_query($con,$query);	
	
	header("location:viewproperty1.php");
	
}
if(isset($_GET['delete_pro']))
{
	$id=$_GET['delete_pro'];
	
	$result1=mysqli_query($con,"select * from propertydetail where propertydetail_id='$id'");
	$row9=mysqli_fetch_array($result1);
		
	$img1=explode(',', $row9['photo']);
			$number_of_photos_delete = count($img1);
						
			for ($i2=0; $i2<$number_of_photos_delete; $i2++) 
			{			
				unlink($img1[$i2]);
			}
	
	$query="delete from propertydetail where propertydetail_id='$id'";
	mysqli_query($con,$query);
	header("location:viewproperty1.php");
}
if(isset($_GET['property_id']))
{
	$id=$_GET['property_id'];
		
	$query="select * from propertydetail where propertydetail_id='$id'";
	$result=mysqli_query($con,$query);
	$row6=mysqli_fetch_array($result);
	
	$check=explode(',',$row6['features']);
}

?>

<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from html-templates.multipurposethemes.com/bootstrap-4/admin/minimaladmin/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Nov 2017 00:46:38 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.ico">

    <title> Admin - Dashboard</title>
    
	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap.css">
	
	<!-- Bootstrap 4.0-->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap-extend.css">
	
	<!-- font awesome -->
	<link rel="stylesheet" href="assets/vendor_components/font-awesome/css/font-awesome.css">
	
	<!-- ionicons -->
	<link rel="stylesheet" href="assets/vendor_components/Ionicons/css/ionicons.css">
	
	<!-- theme style -->
	<link rel="stylesheet" href="css/master_style.css">
	
	<!-- minimal_admin skins. choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
	<link rel="stylesheet" href="css/skins/_all-skins.css">
	
	<!-- weather weather -->
	<link rel="stylesheet" href="assets/vendor_components/weather-icons/weather-icons.css">
	
	<!-- jvectormap -->
	<link rel="stylesheet" href="assets/vendor_components/jvectormap/jquery-jvectormap.css">
	
	<!-- date picker -->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.css">
	
	<!-- daterange picker -->
	<link rel="stylesheet" href="assets/vendor_components/bootstrap-daterangepicker/daterangepicker.css">
	
	<!-- bootstrap wysihtml5 - text editor -->
	<link rel="stylesheet" href="assets/vendor_plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.css">
	

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	
  </head>

<body class="hold-transition skin-blue sidebar-mini">


  <header class="main-header">
    <!-- Logo -->
  <?php
  include("include/header.php");
  ?>


  </header>
  
  <!-- Left side column. contains the logo and sidebar -->
<?php
include("include/sidebar.php");
?>
  <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <section class="content-header">
      <h1>
        Add Property
        
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
		<li class="breadcrumb-item active">Addproperty</li>
      </ol>
	</section>
	
	<div class="box box-warning">
	     <div class="box-body">
              <form action="" method="post" enctype="multipart/form-data" name="myForm" onsubmit="return(validate());">
			  
                <!-- text input -->
                <div class="form-group">
				  <input type="text" class="form-control"  name="propertytitle" value="<?php if(isset($_GET['property_id'])){ echo $row6['propertytitle'];}?>" placeholder="Enter Propertyname">
                <span style="color:red;" id="propertytitle1"></span>
				</div>
				<div class="form-group">
				<?php
					$query="select * from propertystatus";
					$result=mysqli_query($con,$query);
				?>	
                  <select class="form-control" name="propertystatus" id="propertystatus1">
					<option hidden>Select Property Status</option>
					<?php
						while($row1=mysqli_fetch_array($result))
						{
					?>
                    <option <?php if(isset($_GET['property_id'])){ if($row1['propertystatus_id']==$row6['propertystatus_id']){ echo "selected='selected'";}} ?>value="<?php echo $row1['propertystatus_id']; ?>"> <?php echo $row1['propertystatus']; ?></option>
					<?php
						}
					?>
                  </select>
				  <span style="color:red;" id="propertystatus2"></span>
                </div>
				<div class="form-group">
					  <?php
						  $query="select * from  p_category";
						  $result=mysqli_query($con,$query);
					   ?>
			  		<select class="form-control" name="category" id="category1" onchange="pro_category(this.value)">
						<option hidden>Select Category</option>
					  <?php
						  while($row2=mysqli_fetch_array($result))
						  {
					  ?>
							<option <?php if(isset($_GET['property_id'])){ if($row2['category_id']==$row6['category_id']){ echo "selected='selected'";}} ?> value="<?php echo $row2['category_id'];?>"><?php echo $row2['categoryname']; ?></option>
						<?php
						  }
						?>
					</select>
					<span style="color:red;" id="category2"></span>
                  </div>
				  <?php
				  if(isset($_GET['property_id']))
				  {
					  $query="select * from  p_subcategory";
					  $result=mysqli_query($con,$query);
				  ?>
				  <div class="form-group">
					 <select class="form-control" name="subcategory" required>
							<option hidden>Select SubCategory</option>
							<?php
								while($row3=mysqli_fetch_array($result))
								{
							?>
								<option <?php if(isset($_GET['property_id'])){ if($row3['subcat_id']==$row6['subcat_id']){ echo "selected='selected'";}} ?> value="<?php echo $row3['subcat_id'];?>"><?php echo $row3['subcategory']; ?></option>
							<?php
								}
							?>
					</select>
					<span style="color:red;" id="subcategory3"></span>
                  </div>
				  <?php
				  }
				  else{
				  ?>
				  <div class="form-group">
					 <select class="form-control" name="subcategory" id="demo1">
							<option hidden>Select SubCategory</option>
					</select>
					<span style="color:red;" id="subcategory2"></span>
                  </div>
				  <?php
				  }
				  ?>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['minprice'];}?>" name="minprice" placeholder="Enter Min Price">
                </div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['maxprice'];}?>" name="maxprice" placeholder="Enter Max Price">
                <span style="color:red;" id="maxprice2"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['minarea'];}?>" name="minarea" placeholder="Enter Min Area">
                <span style="color:red;" id="minarea1"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['maxarea'];}?>" name="maxarea" placeholder="Enter Max Area">
                <span style="color:red;" id="maxarea1"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['rooms'];}?>" name="rooms" placeholder="Enter Rooms">
                <span style="color:red;" id="rooms1"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['bathrooms'];}?>" name="bathrooms" placeholder="Enter Bathrooms">
                <span style="color:red;" id="bathrooms1"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['balconey'];}?>" name="balconey" placeholder="Enter balconey">
                <span style="color:red;" id="balconey1"></span>
				</div>
				<div class="form-group">
				<?php
					$query="select * from furnished";
					$result14=mysqli_query($con,$query);
				?>	
                  <select class="form-control" name="furnished" id="furnished1">
					<option hidden>Select furnished</option>
					<?php
						while($row14=mysqli_fetch_array($result14))
						{
					?>
                    <option <?php if(isset($_GET['property_id'])){ if($row14['furnished_id']==$row6['furnished_id']){ echo "selected='selected'";}}?> value="<?php echo $row14['furnished_id']; ?>"> <?php echo $row14['furnished']; ?></option>
					<?php
						}
					?>
                  </select>
				  <span style="color:red;" id="furnished2"></span>
                </div>
						
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['floor'];}?>" name="floor" placeholder="Enter floor">
                <span style="color:red;" id="floor1"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['cons_status'];}?>" name="cons_status" placeholder="Enter cons_status">
                <span style="color:red;" id="cons_status1"></span>
				</div>
				<div class="form-group">				
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['date'];}?>" name="date" placeholder="Enter date">
                <span style="color:red;" id="date1"></span>
				</div>				
				  <?php
					if(isset($_GET['property_id']))
					{
						$img=explode(',', $row6['photo']);
						$number_of_photos = count($img);
								 
						$flag = 0;
						for ($i1=0; $i1<$number_of_photos; $i1++) 
						{
							if($flag==0)
							{							
					?>
					<div class="form-group">				
						<img src="<?php echo $img[$i1];?>" width="150" align="right" >
					</div>	
							<?php
							}								
						}	
							
							?>
					<div class="form-group">				
						<input type="file" class="form-control" name="img[]" required multiple >
											
					</div>	
					
				
							<?php
						}
						else
						{
					?>
					<div class="form-group">				
						<input type="file" class="form-control" name="img[]" id="img1" required multiple >
					<span style="color:red;" id="photo1"></span>						
					</div>	
					<?php
						}
					?>
				<div class="form-group">
					<input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['floorno'];}?>" name="floorno" placeholder="Enter floorno">
                <span style="color:red;" id="floorno12"></span>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['complexname'];}?>" name="complexname" placeholder="Enter complexname">
                <span style="color:red;" id="complexname1"></span>
				</div>
				<div class="form-group">
				<?php
					$query="select * from city";
					$result=mysqli_query($con,$query);
				?>	
                  <select class="form-control" name="city" id="city1" onchange="pro_city(this.value)">
					<option hidden>Select City</option>
					<?php
						while($row4=mysqli_fetch_array($result))
						{
					?>
                    <option <?php if(isset($_GET['property_id'])){ if($row4['cityid']==$row6['cityid']){ echo "selected='selected'";}}?> value="<?php echo $row4['cityid']; ?>"> <?php echo $row4['cityname']; ?></option>
					<?php
						}
					?>
                  </select>
				  <span style="color:red;" id="city2"></span>
                </div>
				<?php 
				if(isset($_GET['property_id']))
				{
					$query="select * from area";
					$result8=mysqli_query($con,$query);
				?>
				<div class="form-group">
					<select class="form-control" name="area" id="area1">
						<option hidden>Select Area</option>
						<?php
							while($row5=mysqli_fetch_array($result8))
							{
						?>
							<option <?php if(isset($_GET['property_id'])){ if($row5['area_id']==$row6['area_id']){ echo "selected='selected'";}}?> value="<?php echo $row5['area_id']; ?>"> <?php echo $row5['areaname']; ?></option>
						<?php
						}
						?>
					</select>
					<span style="color:red;" id="area2"></span>
				</div>
				<?php
				}
				else
				{
				?>
				<div class="form-group">
					<select class="form-control" name="area" id="demo2">
						<option hidden>Select Area</option>
					</select>
					<span style="color:red;" id="area3"></span>
				</div>
				<?php
				}
				?>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['postalcode'];}?>" name="postalcode" placeholder="Enter Postal Code">
                <span style="color:red;" id="postalcode1"></span>
				</div>
				<div class="form-group">
                  <textarea class="form-control" rows="3"  name="description" placeholder="Enter Property description"><?php if(isset($_GET['property_id'])){ echo $row6['description'];}?></textarea>
                <span style="color:red;" id="description1"></span>
				</div>	
					<h3>Features</h3>
				<div style="font-size:18px;">
                    <input type="checkbox" name="check[]" required value="freeparking" <?php if(isset($_GET['property_id'])){ if(in_array('freeparking',$check)){ echo "checked='checked'";}}?>>  Free Parking 
					 
					<input type="checkbox" name="check[]" value="swimmingpool" <?php if(isset($_GET['property_id'])){ if(in_array('swimmingpool',$check)){ echo "checked='checked'";}}?>> Swimming Pool
					
				    <input type="checkbox" name="check[]" value="garden" <?php if(isset($_GET['property_id'])){ if(in_array('garden',$check)){ echo "checked='checked'";}}?>> Garden
					
					
					
				</div>
				<div style="font-size:18px;">
                    <input type="checkbox" name="check[]" value="aircondition" <?php if(isset($_GET['property_id'])){ if(in_array('aircondition',$check)){ echo "checked='checked'";}}?>> Air Condition
					
					<input type="checkbox" name="check[]" value="lundryroom" <?php if(isset($_GET['property_id'])){ if(in_array('lundryroom',$check)){ echo "checked='checked'";}}?>> Laundry Room
					
				    					
					<input type="checkbox" name="check[]" value="gas" <?php if(isset($_GET['property_id'])){ if(in_array('gas',$check)){ echo "checked='checked'";}}?>> Piped Gas
					
				</div>
				<div style="font-size:18px;" >
                    <input type="checkbox" name="check[]" value="placetoseat" <?php if(isset($_GET['property_id'])){ if(in_array('placetoseat',$check)){ echo "checked='checked'";}}?>> Places to seat
					
					<input type="checkbox" name="check[]" value="lift" <?php if(isset($_GET['property_id'])){ if(in_array('lift',$check)){ echo "checked='checked'";}}?>> Lift
					
					<input type="checkbox"name="check[]" value="gym" <?php if(isset($_GET['property_id'])){ if(in_array('gym',$check)){ echo "checked='checked'";}}?>> GYM
				</div>
					<h3>Contact Detail</h3>
				
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['email'];}?>" name="email" placeholder="Enter Email">
                <span style="color:red;" id="email"></span>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" value="<?php if(isset($_GET['property_id'])){ echo $row6['phone'];}?>" name="phone" placeholder="Enter PhoneNo">
                <span style="color:red;" id="phone"></span>
				</div>				
				<button type="submit" name="<?php if(isset($_GET['property_id'])){echo"edit";}else{echo"submit";} ?>" style="width:200px;" class="btn btn-primary"><?php if(isset($_GET['property_id'])){echo"EDIT";}else{echo"ADD";} ?></button>				
				</form>
	     </div>
     </div>
 </div>
 
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li class="nav-item"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li class="nav-item"><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-cog fa-spin"></i></a></li>
    </ul>
 </aside>
</div>
<script type="text/javascript">
function validate()
      {
		 // alert("e");		
		var propertytitle = document.myForm.propertytitle.value;
		var maxprice = document.myForm.maxprice.value;
		var minarea = document.myForm.minarea.value;
		var maxarea = document.myForm.maxarea.value;
		var rooms = document.myForm.rooms.value;
		var bathrooms = document.myForm.bathrooms.value;
		var balconey = document.myForm.balconey.value;
		var floor = document.myForm.floor.value;
		var cons_status = document.myForm.cons_status.value;
		var date = document.myForm.date.value;
		var floorno = document.myForm.floorno.value;		
		var complexname = document.myForm.complexname.value;
		var postalcode = document.myForm.postalcode.value;
		var description = document.myForm.description.value;
		var email = document.myForm.email.value;
		var phone = document.myForm.phone.value;		
		
		//alert(maxprice);
		
		if(propertytitle == "")
		 {
		 document.getElementById("propertytitle1").innerHTML="Please Fill propertytitle Filed.";
		 document.myForm.propertytitle.focus() ;
            return false;
         }
		 else{
			 document.getElementById("propertytitle1").innerHTML="";
		 }
		 
		if(maxprice == "")
		 {			 
		 document.getElementById("maxprice2").innerHTML="Please Fill maxprice Filed.";
		 document.myForm.maxprice.focus() ;
            return false;
         }
		 else{
			 document.getElementById("maxprice2").innerHTML="";
		 }
		 if(isNaN(maxprice))
		 {
			document.getElementById("maxprice2").innerHTML="User Must Enter Digit";
            document.myForm.maxprice.focus() ;
            return false;
		 }
		 else{
			document.getElementById("maxprice2").innerHTML=""; 
		 }
		if(minarea == "")
		 {			 
		 document.getElementById("minarea1").innerHTML="Please Fill minarea Filed.";
		 document.myForm.minarea.focus() ;
            return false;
         }
		 else{
			 document.getElementById("minarea1").innerHTML="";
		 }	
		if(isNaN(minarea))
		 {
			document.getElementById("minarea1").innerHTML="User Must Enter Digit";
            document.myForm.minarea.focus() ;
            return false;
		 }
		 else{
			document.getElementById("minarea1").innerHTML=""; 
		 }
		 if(maxarea == "")
		 {			 
		 document.getElementById("maxarea1").innerHTML="Please Fill maxarea Filed.";
		 document.myForm.maxarea.focus() ;
            return false;
         }
		 else{
			 document.getElementById("maxarea1").innerHTML="";
		 }	
		if(isNaN(maxarea))
		 {
			document.getElementById("maxarea1").innerHTML="User Must Enter Digit";
            document.myForm.maxarea.focus() ;
            return false;
		 }
		 else{
			document.getElementById("maxarea1").innerHTML=""; 
		 }
		 if(rooms == "")
		 {			 
		 document.getElementById("rooms1").innerHTML="Please Fill rooms Filed.";
		 document.myForm.rooms.focus() ;
            return false;
         }
		 else{
			 document.getElementById("rooms1").innerHTML="";
		 }	
		if(isNaN(rooms))
		 {
			document.getElementById("rooms1").innerHTML="User Must Enter Digit";
            document.myForm.rooms.focus() ;
            return false;
		 }
		 else{
			document.getElementById("rooms1").innerHTML=""; 
		 }
		  if(bathrooms == "")
		 {			 
		 document.getElementById("bathrooms1").innerHTML="Please Fill bathrooms Filed.";
		 document.myForm.bathrooms.focus() ;
            return false;
         }
		 else{
			 document.getElementById("bathrooms1").innerHTML="";
		 }	
		if(isNaN(bathrooms))
		 {
			document.getElementById("bathrooms1").innerHTML="User Must Enter Digit";
            document.myForm.bathrooms.focus() ;
            return false;
		 }
		 else{
			document.getElementById("bathrooms1").innerHTML=""; 
		 }
		  if(balconey == "")
		 {			 
		 document.getElementById("balconey1").innerHTML="Please Fill balconey Filed.";
		 document.myForm.balconey.focus() ;
            return false;
         }
		 else{
			 document.getElementById("balconey1").innerHTML="";
		 }	
		if(isNaN(balconey))
		 {
			document.getElementById("balconey1").innerHTML="User Must Enter Digit";
            document.myForm.balconey.focus() ;
            return false;
		 }
		 else{
			document.getElementById("balconey1").innerHTML=""; 
		 }
		   if(floor == "")
		 {			 
		 document.getElementById("floor1").innerHTML="Please Fill floor Filed.";
		 document.myForm.floor.focus() ;
            return false;
         }
		 else{
			 document.getElementById("floor1").innerHTML="";
		 }	
		if(isNaN(floor))
		 {
			document.getElementById("floor1").innerHTML="User Must Enter Digit";
            document.myForm.floor.focus() ;
            return false;
		 }
		 else{
			document.getElementById("floor1").innerHTML=""; 
		 }
		 if(cons_status == "")
		 {
		 document.getElementById("cons_status1").innerHTML="Please Fill cons_status Filed.";
		 document.myForm.cons_status.focus() ;
            return false;
         }
		 else{
			 document.getElementById("cons_status1").innerHTML="";
		 }
		 if(date == "")
		 {
		 document.getElementById("date1").innerHTML="Please Fill date Filed. DD-MM-YYYY";
		 document.myForm.date.focus() ;
            return false;
         }
		 else{
			 document.getElementById("date1").innerHTML="";
		 }
		if(floorno == "")
		 {
		 document.getElementById("floorno12").innerHTML="Please Fill floorno Filed.";
		 document.myForm.floorno.focus() ;
            return false;
         }
		 else{
			 document.getElementById("floorno12").innerHTML="";
		 }
		 if(complexname == "")
		 {
		 document.getElementById("complexname1").innerHTML="Please Fill complexname Filed.";
		 document.myForm.complexname.focus() ;
            return false;
         }
		 else{
			 document.getElementById("complexname1").innerHTML="";
		 }
		 if(postalcode == "")
		 {
		 document.getElementById("postalcode1").innerHTML="Please Fill postalcode Filed.";
		 document.myForm.postalcode.focus() ;
            return false;
         }
		 else{
			 document.getElementById("postalcode1").innerHTML="";
		 }
		 if(postalcode.length !=6)
		 {
			document.getElementById("postalcode1").innerHTML="postalcode Must Write 6 digit";
            document.myForm.postalcode.focus() ;
            return false;
		 }
		 else{
			document.getElementById("postalcode1").innerHTML=""; 
		 }
		if(isNaN(postalcode))
		 {
			document.getElementById("postalcode1").innerHTML="User Must Enter Digit";
            document.myForm.postalcode.focus() ;
            return false;
		 }
		 else{
			document.getElementById("postalcode1").innerHTML=""; 
		 }
		if(description == "")
		 {
		 document.getElementById("description1").innerHTML="Please Fill description Filed.";
		 document.myForm.description.focus() ;
            return false;
         }
		 else{
			 document.getElementById("description1").innerHTML="";
		 }	
			if( email == "" )
         {
            document.getElementById("email").innerHTML="Please Fill the Email field";
            document.myForm.email.focus() ;
            return false;
         }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.length <= 2) || (email.length > 20) )
		 {
			document.getElementById("email").innerHTML="user length must be between 2 and 20";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(!isNaN(email))
		 {
			document.getElementById("email").innerHTML="Only character allowed";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if(email.indexOf('@') <= 0)
		 {
			document.getElementById("email").innerHTML="@ Invalid Position ";
            document.myForm.email.focus() ;
            return false;
		 }
		 else{
			document.getElementById("email").innerHTML=""; 
		 }
		 if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
		 {
			document.getElementById("email").innerHTML=". Invalid Position ";
            document.myForm.email.focus() ;
			 return false;
		 }
		 else
		 {
			 document.getElementById("email").innerHTML="";
		 } 		
		 if( phone == "")
		 {
			document.getElementById("phone").innerHTML="Please Fill the phone field";
            document.myForm.phone.focus() ;
            return false; 
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		 if(isNaN(phone))
		 {
			document.getElementById("phone").innerHTML="User Must Enter Digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		 if(phone.length !=10)
		 {
			document.getElementById("phone").innerHTML="Mobile no Must Write 10 digit";
            document.myForm.phone.focus() ;
            return false;
		 }
		 else{
			document.getElementById("phone").innerHTML=""; 
		 }
		var e = document.getElementById("propertystatus1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select Property Status" )
		{
			document.getElementById("propertystatus2").innerHTML="Please Select propertystatus Filed.";
			return false;
			
		}else{
				document.getElementById("propertystatus2").innerHTML="";
			}	
			
		var e = document.getElementById("category1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select Category" )
		{
			document.getElementById("category2").innerHTML="Please Select category Filed.";
			return false;
			
		}else{
				document.getElementById("category2").innerHTML="";
			}
			
		var e = document.getElementById("demo1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;
		
		
		if(strUser==0 || strUser == "Select SubCategory" )
		{
			document.getElementById("subcategory2").innerHTML="Please Select subcategory Filed.";
			return false;
			
		}else{
				document.getElementById("subcategory2").innerHTML="";
			}
		
		var e = document.getElementById("furnished1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;		
		
		if(strUser==0 || strUser == "Select furnished" )
		{
			document.getElementById("furnished2").innerHTML="Please Select furnished Filed.";
			return false;
			
		}else{
				document.getElementById("furnished2").innerHTML="";
			}
		var e = document.getElementById("city1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;		
		
		if(strUser==0 || strUser == "Select City" )
		{
			document.getElementById("city2").innerHTML="Please Select city Filed.";
			return false;
			
		}else{
				document.getElementById("city2").innerHTML="";
			}
		var e = document.getElementById("demo2");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;		
		
		if(strUser==0 || strUser == "Select Area" )
		{
			document.getElementById("area3").innerHTML="Please Select area Filed.";
			return false;
			
		}else{
				document.getElementById("area3").innerHTML="";
			}
			var e = document.getElementById("area1");
		  
		var strUser = e.options[e.selectedIndex].value;
		var strUser1 = e.options[e.selectedIndex].text;		
		
		if(strUser==0 || strUser == "Select Area" )
		{
			document.getElementById("area2").innerHTML="Please Select area Filed.";
			return false;
			
		}else{
				document.getElementById("area2").innerHTML="";
			}
		
		 return( true );			
		 
	  }
</script>
	<!-- jQuery 3 -->
	<script src="assets/vendor_components/jquery/dist/jquery.js"></script>
	
	<!-- jQuery UI 1.11.4 -->
	<script src="assets/vendor_components/jquery-ui/jquery-ui.js"></script>
	
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	  $.widget.bridge('uibutton', $.ui.button);
	</script>
	
	<!-- popper -->
	<script src="assets/vendor_components/popper/dist/popper.min.js"></script>
	
	<!-- Bootstrap 4.0-->
	<script src="assets/vendor_components/bootstrap/dist/js/bootstrap.js"></script>	
	
	<!-- ChartJS -->
	<script src="assets/vendor_components/chart-js/chart.js"></script>
	
	<!-- Sparkline -->
	<script src="assets/vendor_components/jquery-sparkline/dist/jquery.sparkline.js"></script>
	
	<!-- jvectormap -->
	<script src="assets/vendor_plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>	
	<script src="assets/vendor_plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	
	<!-- jQuery Knob Chart -->
	<script src="assets/vendor_components/jquery-knob/js/jquery.knob.js"></script>
	
	<!-- daterangepicker -->
	<script src="assets/vendor_components/moment/min/moment.min.js"></script>
	<script src="assets/vendor_components/bootstrap-daterangepicker/daterangepicker.js"></script>
	
	<!-- datepicker -->
	<script src="assets/vendor_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.js"></script>
	
	<!-- Bootstrap WYSIHTML5 -->
	<script src="assets/vendor_plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.js"></script>
	
	<!-- Slimscroll -->
	<script src="assets/vendor_components/jquery-slimscroll/jquery.slimscroll.js"></script>
	
	<!-- FastClick -->
	<script src="assets/vendor_components/fastclick/lib/fastclick.js"></script>
	
	<!-- minimal_admin App -->
	<script src="js/template.js"></script>
	
	<!-- minimal_admin dashboard demo (This is only for demo purposes) -->
	<script src="js/pages/dashboard.js"></script>
	
	<!-- minimal_admin for demo purposes -->
	<script src="js/demo.js"></script>
	
	<!-- weather for demo purposes -->
	<script src="assets/vendor_plugins/weather-icons/WeatherIcon.js"></script>

	
</body>

<!-- Mirrored from html-templates.multipurposethemes.com/bootstrap-4/admin/minimaladmin/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 Nov 2017 00:47:35 GMT -->
</html>
